<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
<meta name="format-detection" content="telephone=no">
<title>详情</title>
<link rel="stylesheet" href="/Public/Home/css/swiper.min.css">
<link href="/Public/Home/css/globalConfig.css" rel="stylesheet">
<script type="text/javascript" src="/Public/Home/js/jquery-2.2.1.min.js"></script> 
<link href="/Public/Home/css/CommonCss.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/Public/Home/css/diversion.css">
<link href="/Public/Home/css/restaurantdetails.css" rel="stylesheet">
<style type="text/css">
._registerColor {
  color: #5384f6;
}
._top_bgColor {
  background-color: #5384f6;
}
._button_bg {
  background-color: #4196F0;
}
._button_bg1 {
  background-color: #1473D6;
}
._button_bg3 {
  background-color: #1685D3;
}
._button_bg2 {
  border: 1px solid #1476D7;
  color: #1378D8;
  background-color: #f3f3f3;
}
.circlebg {
  background-color: #1375D9;
}
._fontColor {
  color: #ff6738;
}
._button_bg5 {
  background: #5384f6;
}
#bg {
  background: url('/Public/Home/Images/peijing.png');
}
/* changeBox_a1 */
.changeBox_a1 {
  position: relative;
  /*height: 397px;*/
  width: 100%;
  overflow: hidden;
}
.changeBox_imgs {
  position: relative;
  height: 175px;
  width: 100%;
  overflow-x: hidden;
  clear: both;
}
.changeBox_imgs_list {
  position: absolute;
  width: 300%;
}
.changeBox_imgs_list li {
  float: left;
  height: auto;
  display:block;
  width: 33.3%;
}
.changeBox_imgs_list li a img {
  width: 100%;
  height:auto;
}
/* ul_change */
.ul_change, .ul_change .arrow_bar {
  background: url(/Public/Home/Images/bannerTag.gif) repeat-x;
}
.ul_change {
  position: relative;
  width: 100%;
  height: 43px;
  left: 0px;
  bottom: 0px;
  background-position: 0 0;
}
.ul_change .arrow_bar {
  position: absolute;
  width: 33%;
  height: 34px;
  background-position: -3px -46px;
  color: #565253;
  z-index: 8;
  top: 3px;
  left: 3px;
  cursor: pointer;
}
.ul_change li {
  display: block;
  _display: inline-block;
  float: left;
  position: relative;
  width: 30%;
  height: 40px;
  line-height: 40px;
  padding-top: 3px;
  z-index: 9;
  margin: 0 3% 0 .3%;
  text-align: center;
  color: #8F8F8F;
  font-size: 14px;
  font-weight: bolder;
  font-family: '微软雅黑', '宋体';
  cursor: pointer;
}
</style>
</head>
<body style="background-color: black;">
<div id="change_1" class="changeBox_a1">
  <div class="changeBox_imgs">
    <ul class="changeBox_imgs_list">
      <li><a href="" ><img  alt="户外摄影" width="100%" height="175" src="/Public<?php echo ($images[0]); ?>" /></a></li>
      <li><a href="" ><img  alt="户外摄影" width="100%" height="175" src="/Public<?php echo ($images[1]); ?>" /></a></li>
      <li><a href="" ><img  alt="户外摄影" width="100%" height="175" src="/Public<?php echo ($images[2]); ?>" /></a></li>
    </ul>
  </div>
  <ul class="ul_change">
    <li id="changeBox_arrow_bar" class="arrow_bar"></li>
    <li class="tagLi3" idx="1">户外摄影</li>
    <li class="tagLi2" idx="2">室内摄影</li>
    <li class="tagLi1" idx="3">全景摄影</li>
  </ul>
</div>

<div id="title" class="sindonM_border" style="border-color: rgb(76, 76, 76);"> <span class="sindonM_title" style="color: #ccc;"><?php echo ($data["room_name"]); ?>&nbsp;&nbsp;<small><strong>￥ <?php echo ($data["room_price"]); ?>元/天</strong></small></span> </div>
<div id="text" class="sindonM_con" style="color: #ccc;"><?php echo ($data["room_text"]); ?>
  <p><br>
  </p>
  <p style="white-space:normal;font-size:14px;font-family:'Microsoft YaHei';color:#999;text-indent:2em;text-align:justify;line-height:1.5em;"><span style="color:#999;font-size:14px;">面积：<?php echo ($data["room_mx"]); ?>&nbsp;㎡</span></p>
  <p style="white-space:normal;font-size:14px;font-family:'Microsoft YaHei';color:#999;line-height:30px;text-indent:2em;text-align:justify;"><span style="font-size:14px;">可住人数：<?php echo ($data["room_people"]); ?>人</span></p>
  <p style="white-space:normal;font-size:14px;font-family:'Microsoft YaHei';color:#999;line-height:30px;text-indent:2em;text-align:justify;"><span style="font-size:13px;"><span style="font-size:14px;">娱乐设施：<?php echo ($data["room_bath"]); ?></span><span style=""><br>
    </span></span></p>
 <!--  <p style="white-space:normal;font-size:14px;font-family:'Microsoft YaHei';color:#999;line-height:30px;text-indent:2em;text-align:justify;"><span style="font-size:13px;"><span style="font-size:14px;">办公设施：写字台、国内国际电话</span><br>
    </span></p> -->
  <p style="white-space:normal;font-size:14px;font-family:'Microsoft YaHei';color:#999;line-height:30px;text-indent:2em;text-align:justify;"><br>
  </p>
  <p><br>
  </p>
</div>
<div class="topaybtn">
定金：￥<span><?php echo ($data["room_deposit"]); ?>元</span>
	<!-- <a href="/index.php/Home/Pay/weixinpay_js/id/<?php echo ($data["id"]); ?>/state/1" onclick="judge();">去支付</a> -->
	<a id="judge" >去支付</a>
</div>
<!--独立引用-->
</body>
<script type="text/javascript">
function BannerImages(){
  var bodyWidth=document.body.clientWidth;
  //alert(bodyWidth);
  var b = $("#changeBox_arrow_bar"),
    c = $("ul.ul_change li:not(.arrw_bar)"),
    e = $("ul.changeBox_imgs_list"),
    d = true,
    f = 1; 
    
  var a = function(){
    
    var j = (bodyWidth * f - bodyWidth),j = j == 0 ? 0 : -j,i = 500;
    
    e.animate({ left: j + "px" }, i)
  };
    
  e.find("img").hover(function(){
    clearInterval(h)
  },function(){
    g()
  });
    
  c.click(function(){
    var j = $(this), i = j.position().left + 3;
    f = j.attr("idx");
    a();
    b.animate({ left: i + "px" },500,function(){
      d = true
    })
  }).mouseover(function(){
    if(!d){
      return
    }
    clearInterval(h);
    d = false; 
    $(this).click()
  }).mouseout(function(){
    if(!d){
      return
    }
    g()
  });
    
  var h = null;
    
  var g = function(){
    h = setInterval(function(){
      f++;
      if (f > 3){
        f = 1
      }
      c.eq(f).click()
    }, 4000)
  };
  
  g()
  
};

$(document).ready(function(){
  BannerImages();//Banner滑动效果
});



$("#judge").click(function(){
	//判断是否已经停止订房了
	var room_id = <?php echo ($data["id"]); ?>;
	$.post("/index.php/home/index/judge",{id:room_id,state:1},function(data){
		
		if(data==0){
			//正常订房
			window.location.href="/index.php/Home/Pay/weixinpay_js/id/<?php echo ($data["id"]); ?>/state/1";
		}else{
			alert('当前房间已经停止订房了，请返回上一页重新选择');
			window.history.back(-1); 
		}
	
	});
	
})

</script>
</html>