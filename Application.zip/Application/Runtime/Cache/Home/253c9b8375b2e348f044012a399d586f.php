<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html style="font-size: 256.133px;"><head lang="en"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta content="telephone=no, address=no" name="format-detection">
    <link href="/Public/Home/css/CommonCss.css" rel="stylesheet">
    <link href="/Public/Home/css/style.css" rel="stylesheet">
    <link href="/Public/Home/css/globalConfig.css" rel="stylesheet">
    <!--页面独立样式-->
    <link href="/Public/Home/css/matingsecondarypage.css" rel="stylesheet">
    <!--通用js引用-->
    <script src="/Public/Home/js/jquery-2.2.1.min.js"></script>
    <script src="/Public/Home/js/sindonM.js"></script>
    <script src="/Public/Home/js/vsindon.js"></script>
    <title>客房</title>
    <style type="text/css">
	#title{ text-align:left; margin-top:5px; margin-bottom:10px; position:relative; height:30px;}
	#title>span a{float:left; color:#fff; padding:3px 5px; line-height:25px; display:block; font-size:14px;}
	#title>span.active a{ border-bottom:2px solid #666;}
	.model{ margin-top:10px;}
	table.tlist{ margin:0px 1%; border:0; color:#ccc; background-color:#333; border-color:#666; margin-bottom:20px;}
	table.tlist tr td{ padding:2px 1%;}
	table.tlist tr td.orderimg{ padding:0;}
	.tlist img{ width:100%;}
	.tlist .orderid{ font-size:12px; line-height:20px; margin-bottom:0; float:left;}
	.tlist .orderstate{ float:right;}
	.tlist .ordertitle{ font-weight:bold;}
	.tlist .totalprice{ float:right;}
	</style>
</head>
<body class="pdtsingles">
    <div id="title" class="sindonM_border" style="border-color: rgb(0, 0, 0); ">
        <span id="sp1" class=""><a href="/index.php/home/index/get_user_info/orders/1">客房订单</a></span>
        <span id="sp2" class=""><a href="/index.php/home/index/get_user_info/orders/2">会议室订单</a></span>
        <span id="sp3" class=""><a href="/index.php/home/index/get_user_info/orders/3">娱乐室订单</a></span>
        <span id="sp4" class=""><a href="/index.php/home/index/get_user_info/orders/4">餐饮订单</a></span>
    </div>
    

		<?php echo ($str); ?>
<script>

function refund(out_trade_no,total_fee,refund_fee){
    
	var out_trade_no = out_trade_no;
	var total_fee    = total_fee;
	var refund_fee   = refund_fee;
	 
	if(window.confirm('您确定需要申请退款操作吗？')){
	e();
        return true;
     }else{
        return false;
    }
	

function e(){
		window.location.href='/index.php/home/index/refund_post?out_trade_no='+out_trade_no+'&total_fee='+total_fee+'&refund_fee='+refund_fee;
	}

}

$(function(){


	$("#sp<?php echo ($orders); ?>").addClass("active"); 
})


</script>
</html>