<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html style="font-size: 256.133px;"><head lang="en"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta content="telephone=no, address=no" name="format-detection">
    <link href="/Public/Home/css/CommonCss.css" rel="stylesheet">
    <link href="/Public/Home/css/style.css" rel="stylesheet">
    <link href="/Public/Home/css/globalConfig.css" rel="stylesheet">
    <!--页面独立样式-->
    <link href="/Public/Home/css/matingsecondarypage.css" rel="stylesheet">
    <!--通用js引用-->
    <script src="'/Public/Home/js/jquery-2.2.1.min.js"></script>
    <script src="'/Public/Home/js//sindonM.js"></script>
    <script src="'/Public/Home/js/vsindon.js"></script>
    <!--<title>会议娱乐</title>-->
</head>
<body class="pdtsingles">
    <div id="title" class="sindonM_border" style="border-color: rgb(76, 76, 76);">
        <span class="sindonM_text protitle">会议室预订</span>
    </div>
    <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$row): $mod = ($i % 2 );++$i;?><a href="/index.php/home/index/hysxd/id/<?php echo ($row["id"]); ?>.html" class="model">
	       <div style="background-image:url(/Public/<?php echo ($row["conference_image_home"]); ?>)"></div>
	          <div ><span><?php echo ($row["conference_name"]); ?></span><span>了解更多</span></div>
	    </a><?php endforeach; endif; else: echo "" ;endif; ?> 
</body>
</html>