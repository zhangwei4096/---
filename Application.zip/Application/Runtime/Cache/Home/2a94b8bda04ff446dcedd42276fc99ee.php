<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>玉金山大酒店</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="/Public/Home/css/style.css">
  <script src='/Public/Home/js/jquery-2.2.1.min.js' ></script>
</head>

  <style>
  .demo-input{padding-left: 10px; height: 38px; width:100%; min-width: 150px; line-height: 38px; border: 1px solid #e6e6e6;  background-color: #fff;  border-radius: 2px;}
  .demo-footer{padding: 50px 0; color: #999; font-size: 14px;}
  .demo-footer a{padding: 0 5px; color: #01AAED;}
  </style>

<body class="_top_bgColor" style="display: block;">
<form action="<?php echo U('lists');?>" method="post" enctype="multipart/form-data" onsubmit="return s();" >
  <!-- main wrapper -->
  <div class="wrapper">
    <!-- header -->
    <header class="header">
    </header>
    <!-- /header -->
    <!-- parallax -->
      <section class="bg-parallax parallax-window">
        <div class="overlay"></div>
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="parallax-text">
              
                <h2 class="parallax_t __white">千岛湖大酒店</h2>
                <h2 class="parallax_t __green">位于罗甸县龙坪镇五星村。该项目集客房、餐饮、娱乐、会议、健身为一体，是目前罗甸县档次最高、规模最大的高级休闲娱乐和商务中心。</h2>
              </div>
            </div>
            <!-- planner-->
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 planner">
              <div class="planner-block">
                <form class="form-planner form-horizontal">
                  <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <div class="form-group">
                        <label>登记入住</label>
                        <meta content="initial-scale=1.0, minimum-scale=1.0, maximum-scale=2.0, user-scalable=no, width=device-width" name="viewport">
                        <input readonly  name="chcke_time" type="text" class="demo-input" placeholder="请选择日期" id="test1">
                      </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <div class="form-group">
                        <label>离店时间</label>
                        <input readonly name="out_time" type="text" class="demo-input" placeholder="请选择日期" id="test2">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                      <div class="form-group">
                          <label>成人</label>
                          <div class="theme-select">
                            <select name="man" class="form-control __plannerSelect">
                              <option value="1">1</option>
                              <option value="2">2</option>
                              <option value="3">3</option>
                              <option value="4">4</option>
                              <option value="5">5</option>
                              <option value="6">6</option>
                              <option value="7">7</option>
                              <option value="8">8</option>
                              <option value="9">9</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-6">
                      <div class="form-group">
                          <label>儿童</label>
                          <div class="theme-select">
                            <select class="form-control __plannerSelect">
                              <option value="">0</option>
                              <option value="">1</option>
                              <option value="">2</option>
                              <option value="">3</option>
                              <option value="">4</option>
                              <option value="">5</option>
                              <option value="">6</option>
                              <option value="">7</option>
                              <option value="">8</option>
                              <option value="">9</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                      </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                      <div class="planner-check-availability">
                        <input type="submit" class="btn btn-default" value="查询" />
                      </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- /planner-->
          </div>
        </div>
    </section>
    <!-- /parallax -->
    <!-- chose best rooms -->
  </footer>
</div>
<script src="/Public/Home/js/laydate.js"></script> 
    <script type="text/javascript">
    lay('#version').html('-v'+ laydate.v);

  //执行一个laydate实例
  	  laydate.render({
		   elem: '#test1'
		   ,min: 0
		});
  
	  
	  laydate.render({
		    elem: '#test2' //指定元素
		    ,min: 1
		  });
  	
  	
	 
	  
	  function s(){
		  var test1 = $("#test1").val();
		  var test2 = $("#test2").val();
		  
		  if(test1>=test2){
			  alert('离店时间不得小于入住时间');
			  return false;
		  }else{
			  return true;
		  }
		  
	  }
	  
	  
    </script>
<body class="_top_bgColor" style="display: block;">
</form>
</body>
</html>