<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en"><!-- 娱乐室页面 -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
<meta name="format-detection" content="telephone=no">
<link href="/Public/Home/css/globalConfig.css" rel="stylesheet">
<link href="/Public/Home/css/CommonCss.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/Public/Home/css/diversion.css">
<link href="/Public/Home/css/restaurantdetails.css" rel="stylesheet">
<style type="text/css">
h3.cdtitle{ font-size:16px; line-height:35px; color:#ccc; padding:0px 10px;}
._registerColor {
	color: #5384f6;
}
._top_bgColor {
	background-color: #5384f6;
}
._button_bg {
	background-color: #4196F0;
}
._button_bg1 {
	background-color: #1473D6;
}
._button_bg3 {
	background-color: #1685D3;
}
._button_bg2 {
	border: 1px solid #1476D7;
	color: #1378D8;
	background-color: #f3f3f3;
}
.circlebg {
	background-color: #1375D9;
}
._fontColor {
	color: #ff6738;
}
._button_bg5 {
	background: #5384f6;
}
#bg {
	background: url('/Public/Home/Images/peijing.png');
}
.roominfo{ margin:0px auto; color:#ccc }
.roominfo tr td{ border-bottom:1px solid #666; height:40px; line-height:40px; font-size:14px;}
.topaybtn span{ text-decoration:none;}
.ttitle{ background-color:#292929; color:#CCC; width:98%; padding:2px 1%; height:2em; line-height:2em; color:#ccc;}
.topaybtn {
	left: 0;
	bottom: 0rem;
	position: fixed;
	margin-top: -1.4rem;
	width: 100%;
padding-left:.8rem;
	display: block;
	z-index: 9999;
	background-color: rgb(76, 76, 76);
	color: #efefef;
	font-size: large;
	line-height: 3.4rem;
}
.topaybtn span {
	font-size: 1rem;
	line-height: 3.4rem;
	display: inline;
	padding: 1.0rem 1.5rem 0.7rem 0;
	margin-top: 0;
	font-weight: bold;
	font-size: x-large;
	text-decoration: none;
}
.topaybtn a {
	padding: 0.7rem 3.5rem !important;
padding-top:.3rem;
	line-height: 2.4rem;
	font-size: large;
	display: inline;
	background-color: rgb(35, 35, 35);
	font-weight: bold;
	float: right
}
table{ border:none; color:#ccc; font-size:18px;margin-left:2%; margin-right:2%;}
table tr td{ padding:1px 1%; height:2em;}
table img{ width:100%; height:auto;}
.swiper-slide img{ width:100%; height:auto;}
#number{ width:18%; text-align:center;}
#down,#up{ font-size:18px;}
</style>
</head>
<body style="background-color: black;">
<h3 class="cdtitle"><?php echo ($recreation["recreation_name"]); ?></h3>
<div class="swiper-container">
  <div class="swiper-wrapper">
    <div class="swiper-slide"><img src="/Public/Home/Images/danren.jpg" /></div>
 </div>
  <!-- Add Pagination -->
  <div class="swiper-pagination"></div>
</div>
<table class="roominfo" cellpadding="0" cellspacing="0" width="96%" >

<tr>
	<td align="right">房 &nbsp; &nbsp; 费：</td>
    <!-- <td align="left" >闲时：￥<?php echo ($conference["conference_price_min"]); ?>元/小时|忙时：￥<?php echo ($conference["conference_price_max"]); ?>元/小时</td> -->
    <td align="left" ><small><strong><span style="color:#cfa01c">￥<?php echo ($recreation["recreation_price"]); ?>元/时</span></strong></small></td>
</tr>
<tr>
	<td align="right">联 系 人：</td>
    <td align="left" ><input type="text" name="user_name" placeholder="请输入你的名字" id="lianxiren " value="" /></td>
</tr>
<tr>
	<td align="right">联系方式：</td>
    <td align="left" ><input type="text" name="phone" minlength="11" maxlength="11" placeholder="请输入您的11位手机号"  value="" /></td>
</tr>
<tr>
	<td align="right">支付方式：</td>
    <td align="left" colspan="3">微信支付</td>
</tr>
</table>
<div class="topaybtn"><span>定金：￥<?php echo ($data["price"]); ?>元</span> <a id="getOrder" >去付款</a> </div>
<!-- <div class="topaybtn"><button onclick="getOrder()"></button></div> -->
<script src="/Public/Home/js/jquery-2.2.1.min.js"></script>
</body>
<script type="text/javascript">

$(function(){
	
	$("#getOrder").click(function(){
		var user_name   = $("input[name='user_name']").val();  //用户名
		var phone		= $("input[name='phone']").val();     //电话号码
		var id			= <?php echo ($data["id"]); ?>;
		
		if(user_name.length<2){
			alert('请输入您的姓名');
			exit();
		}
		if(phone.length<11){
			alert('请正确输入电话号码');
			exit();
		}
		
		 $.post("/index.php/api/weixinpay/recreation_ajax_post",{
			 user_name:user_name,
			 phone:phone,
			 id:id,
			},function(data){
			
			if(data==1){
				//验证通过后页面跳转
				
				window.location.href="/index.php/api/weixinpay/pay/out_trade_no/<?php echo ($data["out_trade_no"]); ?>";
				
			}else{
				alert('订单提交失败，请重试');
				exit();
			}
		});
		 
	});
	
	
})

</script>
</html>