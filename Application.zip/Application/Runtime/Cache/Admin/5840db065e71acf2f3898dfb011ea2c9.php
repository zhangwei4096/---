<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html zh="zh-CN">
    <head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>管理系统</title>
		<meta http-equiv="Pragma" contect="no-cache">
		<meta name="description" content="管理系统">
		<meta name="keywords" content="管理系统">
		<link rel="icon" href="/Public/admin/images/favicon_16.ico">
		<link rel="shortcut icon" href="/Public/admin/images/favicon_16.ico"  type="image/x-icon">
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/font-awesome.min.css" />
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/common.css" />
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/main.css" />
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/beyond.min.css" />
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/demo.min.css" />
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/boolw.css" />
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/ssstyle.css" />
        <link rel="stylesheet" href="/Public/admin/css/styles696666.css" type="text/css" />


        <script type="text/javascript" src="/Public/admin/js/jquery-1.11.0.min.js"></script>
        <script type="text/javascript" src="/Public/admin/js/e-smart-zoom-jquery.min.js"></script>
		<script type="text/javascript" src="/Public/admin/js/jquery-2.0.3.min.js"></script>
		<script type="text/javascript" src="/Public/admin/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="/Public/admin/js/index.js"></script>
		<script type="text/javascript" src="/Public/admin/js/skins.min.js"></script>
		<script type="text/javascript" src="/Public/admin/js/slimscroll/jquery.slimscroll.min.js"></script>
		<script type="text/javascript" src="/Public/admin/js/boolw/jquery.boolw.js"></script>
		<script type="text/javascript" src="/Public/admin/js/ui/jedate.js"></script>
		<script type="text/javascript" src="/Public/admin/js/editor/kindeditor.js"></script>
		<script type="text/javascript" src="/Public/admin/js/layer.js"></script>
		<!--[if lt IE 9]>
		<script type="text/javascript" src="/Public/admin/js/html5shiv.min.js"></script>
		<![endif]-->
</head>
<body>
<div class="navbar">
    <div class="navbar-inner">
        <div class="navbar-container">
            <!-- Navbar Barnd -->
            <div class="navbar-header pull-left">
                <a href="#" class="navbar-brand">
                    <small>
                        <img src="/Public/admin/images/logo.png" alt="" />
                    </small>
                </a>
            </div>
            <!-- /Navbar Barnd -->
            <!-- Sidebar Collapse -->
            <div class="sidebar-collapse" id="sidebar-collapse">
                <i class="collapse-icon fa fa-bars">
                </i>
            </div>
            <!-- /Sidebar Collapse -->
            <!-- Account Area and Settings --->
            <div class="navbar-header pull-right">
                <div class="navbar-account">
                    <ul class="account-area">
                        <li>
                            <a class="login-area dropdown-toggle" data-toggle="dropdown">
                                <div class="avatar" title="View your public profile">
                                    <img src="/Public/admin/images/avatars/adam-jansen.jpg">
                                </div>
                                <section>
                                    <h2>
                                        <span class="profile"><span>欢迎您！<?php echo (session('username')); ?></span></span>
                                    </h2>
                                </section>
                            </a>
                            <!--Login Area Dropdown-->
                            <ul class="pull-right dropdown-menu dropdown-arrow dropdown-login-area">
                                <li class="username">
                                    <a href="http://boolw.com" title="千岛湖">
                                       	千岛湖
                                    </a>
                                </li>
                                <li class="email">
                                    <a>
                                        
                                    </a>
                                </li>
                                <!--Avatar Area-->
                                <li>
                                    <div class="avatar-area">
                                        <img src="/Public/admin/images/avatars/adam-jansen.jpg" class="avatar">
                                    </div>
                                </li>
                                <!--Theme Selector Area-->
                                <li class="theme-area">
                                    <ul class="colorpicker" id="skin-changer">
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#5DB2FF;" rel="/Public/admin/css/skins/blue.min.css">
                                            </a>
                                        </li>
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#2dc3e8;" rel="/Public/admin/css/skins/azure.min.css">
                                            </a>
                                        </li>
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#03B3B2;" rel="/Public/admin/css/skins/teal.min.css">
                                            </a>
                                        </li>
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#53a93f;" rel="/Public/admin/css/skins/green.min.css">
                                            </a>
                                        </li>
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#FF8F32;" rel="/Public/admin/css/skins/orange.min.css">
                                            </a>
                                        </li>
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#cc324b;" rel="/Public/admin/css/skins/pink.min.css">
                                            </a>
                                        </li>
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#AC193D;" rel="/Public/admin/css/skins/darkred.min.css">
                                            </a>
                                        </li>
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#8C0095;" rel="/Public/admin/css/skins/purple.min.css">
                                            </a>
                                        </li>
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#0072C6;" rel="/Public/admin/css/skins/darkblue.min.css">
                                            </a>
                                        </li>
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#585858;" rel="/Public/admin/css/skins/gray.min.css">
                                            </a>
                                        </li>
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#474544;" rel="/Public/admin/css/skins/black.min.css">
                                            </a>
                                        </li>
                                        <li>
                                            <a class="colorpick-btn" href="#" style="background-color:#001940;" rel="/Public/admin/css/skins/deepblue.min.css">
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <!--/Theme Selector Area-->
                                <li class="dropdown-footer">
                                    <a href="/index.php/Login/signout">
                                        退出系统
                                    </a>
                                </li>
                            </ul>
                            <!--/Login Area Dropdown-->
                        </li>
                        <li>
                            <a class="wave in" title="Chat" href="<?php echo U('Login/logout');?>" title="退出系统">
                                <i class="icon fa fa-sign-out">
                                </i>
                            </a>
                        </li>
                        <!-- /Account Area -->
                        <!--Note: notice that setting div must start right after account area list.
                        no space must be between these elements-->
                        <!-- Settings -->
                    </ul>
                    <div class="setting">
                        <a id="btn-setting" title="Setting" href="#">
                            <i class="icon glyphicon glyphicon-cog">
                            </i>
                        </a>
                    </div>
                    <div class="setting-container">
                        <label>
                            <input type="checkbox" id="checkbox_fixednavbar">
                            <span class="text">Fixed Navbar</span>
                        </label>
                        <label>
                            <input type="checkbox" id="checkbox_fixedsidebar">
                            <span class="text">Fixed SideBar</span>
                        </label>
                        <label>
                            <input type="checkbox" id="checkbox_fixedbreadcrumbs">
                            <span class="text">Fixed BreadCrumbs</span>
                        </label>
                        <label>
                            <input type="checkbox" id="checkbox_fixedheader">
                            <span class="text">Fixed Header</span>
                        </label>
                    </div>
                    <!-- Settings -->
                </div>
            </div>
            <!-- /Account Area and Settings -->
        </div>
    </div>
</div>
<!-- /Navbar -->
<!-- Main Container -->
<div class="main-container container-fluid">
    <!-- Page Container -->
    <div class="page-container">
        <!-- Page Sidebar -->
        <div class="page-sidebar" id="sidebar">
            <ul class="nav sidebar-menu">
                <!--<li>
                    <a href="/index.php/Index" target="_blank">
                        <i class="menu-icon glyphicon glyphicon-home"></i>
                        <span class="menu-text"> 首页 </span>
                    </a>
                </li>-->
                <li>
                    <a href="#" class="menu-dropdown">
                        <i class="menu-icon fa fa-building-o"></i>
                        <span class="menu-text"> 客房管理 </span>
                        <i class="menu-expand"></i>
                    </a>
                    <ul class="submenu">
                        <li>
                            <a href="<?php echo U('Main/room_list');?>">
                                <span class="menu-text">客房列表</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo U('Main/room_add');?>">
                                <span class="menu-text">发布客房</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#" class="menu-dropdown">
                        <i class="menu-icon fa fa-building-o"></i>
                        <span class="menu-text">  会议室管理 </span>
                        <i class="menu-expand"></i>
                    </a>
                    <ul class="submenu">
                        <li>
                            <a href="<?php echo U('Main/conference_room_list');?>">
                                <span class="menu-text">会议室列表</span>
                            </a>
                        </li>
                    </ul>
                     <ul class="submenu">
                        <li>
                            <a href="<?php echo U('Main/conference_room_add');?>">
                                <span class="menu-text">发布会议室</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#" class="menu-dropdown">
                        <i class="menu-icon fa fa-building-o"></i>
                        <span class="menu-text">  娱乐室管理 </span>
                        <i class="menu-expand"></i>
                    </a>
                    <ul class="submenu">
                        <li>
                            <a href="<?php echo U('Main/recreation_room_list');?>">
                                <span class="menu-text">娱乐室管理</span>
                            </a>
                        </li>
                    </ul>
                     <ul class="submenu">
                        <li>
                            <a href="<?php echo U('Main/servers_room_add1');?>">
                                <span class="menu-text">发布娱乐室</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#" class="menu-dropdown">
                        <i class="menu-icon fa fa-building-o"></i>
                        <span class="menu-text">  餐饮管理 </span>
                        <i class="menu-expand"></i>
                    </a>
                    <ul class="submenu">
                        <li>
                            <a href="<?php echo U('Main/restaurant_list');?>">
                                <span class="menu-text">餐饮列表</span>
                            </a>
                        </li>
                    </ul>
                     <ul class="submenu">
                        <li>
                            <a href="<?php echo U('servers_room_add');?>">
                                <span class="menu-text">发布餐饮</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#" class="menu-dropdown">
                        <i class="menu-icon fa fa-building-o"></i>
                        <span class="menu-text">  订单管理 </span>
                        <i class="menu-expand"></i>
                    </a>
                    <ul class="submenu">
                        <li>
                            <a href="<?php echo U('Main/orders_list');?>/radios/1">
                                <span class="menu-text">客房订单列表</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo U('Main/orders_list1');?>/radios/1">
                                <span class="menu-text">会议订单列表</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo U('Main/orders_list3');?>/radios/1">
                                <span class="menu-text">娱乐订单列表</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo U('Main/orders_list4');?>/radios/1">
                                <span class="menu-text">餐饮订单列表</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#" class="menu-dropdown">
                        <i class="menu-icon fa fa-cog"></i>
                        <span class="menu-text"> 管理人员 </span>
                        <i class="menu-expand"></i>
                    </a>
                    <ul class="submenu">
                        <li>
                            <a href="<?php echo U('Main/admin_list');?>">
                                <span class="menu-text">管理管理员</span>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
        <!-- /Page Sidebar -->
        <!-- Chat Bar -->
        <div id="chatbar" class="page-chatbar">
            <div class="chatbar-contacts">
                <div class="contacts-search">
                    <input type="text" class="searchinput" placeholder="Search Contacts" />
                    <i class="searchicon fa fa-search">
                    </i>
                    <div class="searchhelper">
                        Search Your Contacts and Chat History
                    </div>
                </div>
                <ul class="contacts-list">
                    <li class="contact">
                        <div class="contact-avatar">
                            <img src="/Public/admin/images/avatars/divyia.jpg" />
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">
                                Divyia Philips
                            </div>
                            <div class="contact-status">
                                <div class="online">
                                </div>
                                <div class="status">
                                    online
                                </div>
                            </div>
                            <div class="last-chat-time">
                                last week
                            </div>
                        </div>
                    </li>
                    <li class="contact">
                        <div class="contact-avatar">
                            <img src="/Public/admin/images/avatars/Nicolai-Larson.jpg" />
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">
                                Adam Johnson
                            </div>
                            <div class="contact-status">
                                <div class="offline">
                                </div>
                                <div class="status">
                                    left 4 mins ago
                                </div>
                            </div>
                            <div class="last-chat-time">
                                today
                            </div>
                        </div>
                    </li>
                    <li class="contact">
                        <div class="contact-avatar">
                            <img src="/Public/admin/images/avatars/John-Smith.jpg" />
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">
                                John Smith
                            </div>
                            <div class="contact-status">
                                <div class="online">
                                </div>
                                <div class="status">
                                    online
                                </div>
                            </div>
                            <div class="last-chat-time">
                                1:57 am
                            </div>
                        </div>
                    </li>
                    <li class="contact">
                        <div class="contact-avatar">
                            <img src="/Public/admin/images/avatars/Osvaldus-Valutis.jpg" />
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">
                                Osvaldus Valutis
                            </div>
                            <div class="contact-status">
                                <div class="online">
                                </div>
                                <div class="status">
                                    online
                                </div>
                            </div>
                            <div class="last-chat-time">
                                today
                            </div>
                        </div>
                    </li>
                    <li class="contact">
                        <div class="contact-avatar">
                            <img src="/Public/admin/images/avatars/Javi-Jimenez.jpg" />
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">
                                Javi Jimenez
                            </div>
                            <div class="contact-status">
                                <div class="online">
                                </div>
                                <div class="status">
                                    online
                                </div>
                            </div>
                            <div class="last-chat-time">
                                today
                            </div>
                        </div>
                    </li>
                    <li class="contact">
                        <div class="contact-avatar">
                            <img src="/Public/admin/images/avatars/Stephanie-Walter.jpg" />
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">
                                Stephanie Walter
                            </div>
                            <div class="contact-status">
                                <div class="online">
                                </div>
                                <div class="status">
                                    online
                                </div>
                            </div>
                            <div class="last-chat-time">
                                yesterday
                            </div>
                        </div>
                    </li>
                    <li class="contact">
                        <div class="contact-avatar">
                            <img src="/Public/admin/images/avatars/Sergey-Azovskiy.jpg" />
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">
                                Sergey Azovskiy
                            </div>
                            <div class="contact-status">
                                <div class="offline">
                                </div>
                                <div class="status">
                                    offline since oct 24
                                </div>
                            </div>
                            <div class="last-chat-time">
                                22 oct
                            </div>
                        </div>
                    </li>
                    <li class="contact">
                        <div class="contact-avatar">
                            <img src="/Public/admin/images/avatars/Lee-Munroe.jpg" />
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">
                                Lee Munroe
                            </div>
                            <div class="contact-status">
                                <div class="online">
                                </div>
                                <div class="status">
                                    online
                                </div>
                            </div>
                            <div class="last-chat-time">
                                today
                            </div>
                        </div>
                    </li>
                    <li class="contact">
                        <div class="contact-avatar">
                            <img src="/Public/admin/images/avatars/divyia.jpg" />
                        </div>
                        <div class="contact-info">
                            <div class="contact-name">
                                Divyia Philips
                            </div>
                            <div class="contact-status">
                                <div class="online">
                                </div>
                                <div class="status">
                                    online
                                </div>
                            </div>
                            <div class="last-chat-time">
                                last week
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="chatbar-messages" style="display: none;">
                <div class="messages-contact">
                    <div class="contact-avatar">
                        <img src="/Public/admin/images/avatars/divyia.jpg" />
                    </div>
                    <div class="contact-info">
                        <div class="contact-name">
                            Divyia Philips
                        </div>
                        <div class="contact-status">
                            <div class="online">
                            </div>
                            <div class="status">
                                online
                            </div>
                        </div>
                        <div class="last-chat-time">
                            a moment ago
                        </div>
                        <div class="back">
                            <i class="fa fa-arrow-circle-left">
                            </i>
                        </div>
                    </div>
                </div>
                <ul class="messages-list">
                    <li class="message">
                        <div class="message-info">
                            <div class="bullet">
                            </div>
                            <div class="contact-name">
                                Me
                            </div>
                            <div class="message-time">
                                10:14 AM, Today
                            </div>
                        </div>
                        <div class="message-body">
                            Hi, Hope all is good. Are we meeting today?
                        </div>
                    </li>
                    <li class="message reply">
                        <div class="message-info">
                            <div class="bullet">
                            </div>
                            <div class="contact-name">
                                Divyia
                            </div>
                            <div class="message-time">
                                10:15 AM, Today
                            </div>
                        </div>
                        <div class="message-body">
                            Hi, Hope all is good. Are we meeting today?
                        </div>
                    </li>
                    <li class="message">
                        <div class="message-info">
                            <div class="bullet">
                            </div>
                            <div class="contact-name">
                                Me
                            </div>
                            <div class="message-time">
                                10:14 AM, Today
                            </div>
                        </div>
                        <div class="message-body">
                            Hi, Hope all is good. Are we meeting today?
                        </div>
                    </li>
                    <li class="message reply">
                        <div class="message-info">
                            <div class="bullet">
                            </div>
                            <div class="contact-name">
                                Divyia
                            </div>
                            <div class="message-time">
                                10:15 AM, Today
                            </div>
                        </div>
                        <div class="message-body">
                            Hi, Hope all is good. Are we meeting today?
                        </div>
                    </li>
                    <li class="message">
                        <div class="message-info">
                            <div class="bullet">
                            </div>
                            <div class="contact-name">
                                Me
                            </div>
                            <div class="message-time">
                                10:14 AM, Today
                            </div>
                        </div>
                        <div class="message-body">
                            Hi, Hope all is good. Are we meeting today?
                        </div>
                    </li>
                    <li class="message reply">
                        <div class="message-info">
                            <div class="bullet">
                            </div>
                            <div class="contact-name">
                                Divyia
                            </div>
                            <div class="message-time">
                                10:15 AM, Today
                            </div>
                        </div>
                        <div class="message-body">
                            Hi, Hope all is good. Are we meeting today?
                        </div>
                    </li>
                </ul>
                <div class="send-message">
                    <span class="input-icon icon-right">
                        <textarea rows="4" class="form-control" placeholder="Type your message"></textarea>																																
                        <i class="fa fa-camera themeprimary">
                        </i>
                    </span>
                </div>
            </div>
        </div>
        <!-- /Chat Bar -->
        <!-- Page Content -->
        <div class="page-content">
            <!-- Page Header -->
            <div class="page-header position-relative">
                <div class="header-title">
                    <!-- Page Breadcrumb -->
                    <ul class="breadcrumb" id="breadcrumbs">
                        <li>
                            <a href="<?php echo U('Admin/index/index');?>">首页</a>
                        </li>
                        <li class="active">当前页</li>
                    </ul>
                    <!-- /Page Breadcrumb -->
                </div>
                <!--Header Buttons-->
                <div class="header-buttons">
                    <a class="sidebar-toggler" href="#">
                        <i class="fa fa-arrows-h">
                        </i>
                    </a>
                    <a class="refresh" id="refresh-toggler" href="#">
                        <i class="glyphicon glyphicon-refresh">
                        </i>
                    </a>
                    <a class="fullscreen" id="fullscreen-toggler" href="#">
                        <i class="glyphicon glyphicon-fullscreen">
                        </i>
                    </a>
                </div>
                <!--Header Buttons End-->
            </div>
            <!-- /Page Header -->
            <!-- Page Body -->
            <div class="page-body">
            


<div class="row">
	<div class="col-lg-12 col-sm-12 col-xs-12">
		<div class="tabbable">
			<div class="tab-content well  with-footer">
				<div class="buttons-preview">
					<div class="pull-right" style="width:100%">
						<form class="form-horizontal form-inline" role="form" action="/index.php/admin/main/orders_list3" method="get">
							
							<div class="col-sm-7">
								<div class="form-group">
									<!-- <div class="input-group">
										<span class="input-group-addon">筛选时间</span>
										<input type="text"  class="form-control" id="stime" name="stime" value="<?php echo ($stime); ?>" placeholder="输入搜索条件" />
										<input type="text"  class="form-control" id="dtime" name="dtime" value="<?php echo ($dtime); ?>" placeholder="输入搜索条件" />
									</div> -->

<script>
jeDate({
	dateCell:"#stime",  //目标元素。由于jedate.js封装了一个轻量级的选择器，因此dateCell还允许你传入class、tag这种方式 '#id .class'
	format:"YYYY-MM-DD  ",
	isinitVal:false, //显示时间
	isTime:true, 
    festival: true, //显示节日
	minDate:"2014-09-19 00:00:00"
})
jeDate({
	dateCell:"#dtime",  //目标元素。由于jedate.js封装了一个轻量级的选择器，因此dateCell还允许你传入class、tag这种方式 '#id .class'
	format:"YYYY-MM-DD",//hh:mm:ss
	isinitVal:false, //显示时间
	isTime:true, 
    festival: true, //显示节日
	minDate:"2014-09-19 00:00:00"
})
</script>
<style type="text/css">
#juzhong tr td {
text-align:center; /*设置水平居中*/
vertical-align:middle;/*设置垂直居中*/
}
#juzhong tr th {
text-align:center; /*设置水平居中*/
vertical-align:middle;/*设置垂直居中*/
}
</style>
<style type="text/css">
#juzhong tr td {
text-align:center; /*设置水平居中*/
vertical-align:middle;/*设置垂直居中*/
}
#juzhong tr th {
text-align:center; /*设置水平居中*/
vertical-align:middle;/*设置垂直居中*/
}

/* 状态按钮 */
.form-horizontal .statflag{ margin-left:10%;}
.statflag span{ float:left; padding:0px 10px; display:block;}
/*单选*/
.radio_box{ display:inline-block; position:relative;}
.radio_box label{ width:12px; height:12px; position:absolute; top:2px; left:0; border:2px solid #53a93f; border-radius:50%; background:#fff; cursor:pointer;}
.radio_box input:checked + label:after{ content:''; width:4px; height:4px; position:absolute; top:2px; left:2px; background:#53a93f; border-radius:50%;}
.radio_box em{ margin:0 0 0 6px;}
</style>

									<div class="input-group" >
										<span class="input-group-addon">联系电话</span>
										<input type="text"  class="form-control" name="search" value="<?php echo ($search); ?>" placeholder="输入搜索条件" />
									</div>
								</div>
							</div>
							<div class="form-group" style="padding:2px 0 0 0">
								<div class="col-sm-2">
									<button type="submit" class="btn btn-success"><i class="fa fa-search"></i>搜索</button>
								</div>
							</div>
                            <div class="form-group" style="padding:0 20px 0 0;float:right">
								<img class="closeico" src="/Public/admin/images/closeicon.png" onclick="end_conference();" />
							</div>
							 <div class="form-group statflag" style="padding:2px 0 0 0">
								<div>
									<span class="radio_box"><input type="radio" name="radio" id="radio_1" value="1" /><label for="radio_1"></label><em>全&nbsp;&nbsp;部</em></span>
                                    <span class="radio_box"><input type="radio" name="radio" id="radio_2" value="2" /><label for="radio_2"></label><em>待&nbsp;&nbsp;处&nbsp;&nbsp;理</em></span>
                                    <span class="radio_box"><input type="radio" name="radio" id="radio_3" value="3" /><label for="radio_3"></label><em>已&nbsp;&nbsp;接&nbsp;&nbsp;单</em></span>
                                    <span class="radio_box"><input type="radio" name="radio" id="radio_4" value="4" /><label for="radio_4"></label><em>已&nbsp;&nbsp;拒&nbsp;&nbsp;单</em></span>
                                    <span class="radio_box"><input type="radio" name="radio" id="radio_5" value="5" /><label for="radio_5"></label><em>已&nbsp;&nbsp;取&nbsp;&nbsp;消</em></span>
                                   <!--  <span class="radio_box"><input type="radio" name="radio" id="radio_6" value="6" /><label for="radio_6"></label><em>待&nbsp;&nbsp;入&nbsp;&nbsp;住</em></span>
                                    <span class="radio_box"><input type="radio" name="radio" id="radio_7" value="7" /><label for="radio_7"></label><em>今&nbsp;&nbsp;日&nbsp;&nbsp;入&nbsp;&nbsp;住</em></span> -->
                                    <span class="radio_box"><input type="radio" name="radio" id="radio_8" value="8" /><label for="radio_8"></label><em>今&nbsp;&nbsp;日&nbsp;&nbsp;新&nbsp;&nbsp;订</em></span>
								</div>
							</div>
						</form>
					</div>
				</div>
				<table class="table table-hover table-checkbox" id="juzhong">
					<thead class="bordered-darkorange">
						<tr>
							<th>ID</th>
	                        <th>订单号码</th>
	                        <th>手机号</th>
							<th>客户姓名</th>
							<th>支付时间</th>
							<th>娱乐室</th>
							<th>支付定金价格</th>
							<th>接单状态</th>
							<th>信息备注</th>
						</tr>
					</thead>
					<tbody>
						<?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><tr>
								<th><?php echo ($val["id"]); ?></th>
								<td><?php echo ($val["out_trade_no"]); ?></td> 
								<td><?php echo ($val["phone"]); ?></td>
								<td><?php echo ($val["name"]); ?></td>
								<td><?php echo ($val["time_end"]); ?></td>
								<td><?php echo ($val["recreation_name"]); ?></td>
								<td><?php echo ($val["price"]); ?></td>
								<td onclick="B(<?php echo ($val["id"]); ?>);"><?php if(($val["power"]) == "0"): ?><span style="color:blue;">待处理</span><?php endif; if(($val["power"]) == "1"): ?><span style="color:green;">已接单</span><?php endif; if(($val["power"]) == "2"): ?><span style="color:red;">已拒单</span><?php endif; ?></td>
								<td><?php echo ($val["text"]); ?>
								<a href="/index.php/admin/main/orders_list2/id/<?php echo ($val["id"]); ?>/room/2" data-toggle="modal" data-target="#modal-edit" ><i class="fa fa-edit"></i></a>
								</td>
							</tr><?php endforeach; endif; else: echo "" ;endif; ?>
					</tbody>
				</table>
				<span style="text-align:center;"><?php echo ($page); ?></span>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
function end_conference(){
	$.post("/index.php/admin/main/end_recreation",function(data){
		//点击关闭声音提醒公司
		if(data==1){
			alert('确认关闭订单提醒成功');
			location=location;
		}
		
	})
}


$('input[name=radio]').click(function(){
	
	var a = $("input[name='radio']:checked").val();   //单选框radio的值
	location.href="/index.php/admin/main/orders_list3/radios/"+a;
	
	
})

$(function(){
	$('#radio_<?php echo ($radio); ?>').eq(0).attr("checked",true);
})	

function B(id){
	//接单状态更改
	$.post("/index.php/admin/main/orders_state_edit",{id:id,room:3},function(data){
		 if(data==1){
			alert('订单修改为已接单状态');
			location=location;
		}else if(data==2){
			alert('订单无需修改状态');
		}else{
			alert('操作失败');
		}
		
	})
	
}

</script>
			</div>
        </div>
        <!-- /Page Content -->
    </div>
    <!-- /Page Container -->
    <!-- Main Container -->
</div>
<meta name="author" />
<style type="text/css">
	@media (min-width: 768px){
		#modal-notice .modal-dialog{margin: 200px auto;}
	}
</style>
<!--Modal Templates-->
<!--LArge Modal Templates-->
<div class="modal fade" id="modal-add" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
		</div>
	</div>
</div>
<div class="modal fade" id="modal-edit" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
		</div>
	</div>
</div>
<div class="modal fade" id="modal-table" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
		</div>
	</div>
</div>
<div class="modal fade" id="iframe-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<iframe src="" border="0" frameborder="0" id="iframe-modal-dialog" scrolling="no" width="100%" height="90%"></iframe>
		</div>
		<button type="button" data-dismiss="modal" class="hidden" id="iframe-modal-close"></button>
	</div>
</div>
<!--End Large Modal Templates-->
<!--Success Modal Templates-->
<div id="modal-notice" class="modal modal-message fade" style="display: none;" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<i class="glyphicon glyphicon-check"></i>
			</div>
			<div class="modal-title">
				Success
			</div>
			<div class="modal-body">
				You have done great!
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success" data-dismiss="modal">
					OK
				</button>
			</div>
		</div> 
	</div> 
</div>
<!--End Success Modal Templates-->
<!--End Modal Templates-->
<!--选择模态框关闭链接-->
<a href="#iframe-modal" _href="" data-toggle="modal" id="selected_iframe" data-target="#iframe-modal" class="hidden"></a>
<script type="text/javascript" src="/Public/admin/js/bootbox/bootbox.js"></script>
<script type="text/javascript" src="/Public/admin/js/boolw/modal.init.js"></script>
<script type="text/javascript" src="/Public/admin/js/beyond.js"></script>
<script type="text/javascript" src="/Public/admin/js/boolw/boolw.js"></script>


<script>
setInterval("orders()",3000);

	function orders(){
                
           $.post("/index.php/admin/main/orders_post",function(data){
                var str = data; 
                var obj = eval('(' + str + ')'); 
                var room = obj.room; 
                var conference = obj.conference;
                var recreation = obj.recreation;
                var restaurant = obj.restaurant;
                
                if(room!=null){
	                        rooms();
                }               
        

        		if(conference!=null){
	                        conferences();
                }   

                if(recreation!=null){
	                        recreations();
                }   


                if(restaurant!=null){
	                        restaurants();
                }   

                

                });

 };

function rooms()
	    {
	      var borswer = window.navigator.userAgent.toLowerCase();
	      if ( borswer.indexOf( "ie" ) >= 0 )
	      {
	        //IE内核浏览器
	        var strEmbed = '<embed name="embedPlay" src="/Public/admin/mp3/kf.mp3" autostart="true" hidden="true" loop="false"></embed>';
	        if ( $( "body" ).find( "embed" ).length <= 0 )
	          $( "body" ).append( strEmbed );
	        var embed = document.embedPlay;

	        //浏览器不支持 audion，则使用 embed 播放
	        embed.volume = 100;
	        //embed.play();
	      } else
	      {
	        //非IE内核浏览器
	        var strAudio = "<audio id='audioPlay' src='/Public/admin/mp3/kf.mp3' hidden='true'>";
	        if ( $( "body" ).find( "audio" ).length <= 0 )
	          $( "body" ).append( strAudio );
	        var audio = document.getElementById( "audioPlay" );

	        //浏览器支持 audion
	        audio.play();
	      }
	    };

function conferences()
	    {
	      var borswer = window.navigator.userAgent.toLowerCase();
	      if ( borswer.indexOf( "ie" ) >= 0 )
	      {
	        //IE内核浏览器
	        var strEmbed = '<embed name="embedPlay" src="/Public/admin/mp3/hys.mp3" autostart="true" hidden="true" loop="false"></embed>';
	        if ( $( "body" ).find( "embed" ).length <= 0 )
	          $( "body" ).append( strEmbed );
	        var embed = document.embedPlay;

	        //浏览器不支持 audion，则使用 embed 播放
	        embed.volume = 100;
	        //embed.play();
	      } else
	      {
	        //非IE内核浏览器
	        var strAudio = "<audio id='audioPlay' src='/Public/admin/mp3/hys.mp3' hidden='true'>";
	        if ( $( "body" ).find( "audio" ).length <= 0 )
	          $( "body" ).append( strAudio );
	        var audio = document.getElementById( "audioPlay" );

	        //浏览器支持 audion
	        audio.play();
	      }
	    };

function recreations()
	    {
	      var borswer = window.navigator.userAgent.toLowerCase();
	      if ( borswer.indexOf( "ie" ) >= 0 )
	      {
	        //IE内核浏览器
	        var strEmbed = '<embed name="embedPlay" src="/Public/admin/mp3/yls.mp3" autostart="true" hidden="true" loop="false"></embed>';
	        if ( $( "body" ).find( "embed" ).length <= 0 )
	          $( "body" ).append( strEmbed );
	        var embed = document.embedPlay;

	        //浏览器不支持 audion，则使用 embed 播放
	        embed.volume = 100;
	        //embed.play();
	      } else
	      {
	        //非IE内核浏览器
	        var strAudio = "<audio id='audioPlay' src='/Public/admin/mp3/yls.mp3' hidden='true'>";
	        if ( $( "body" ).find( "audio" ).length <= 0 )
	          $( "body" ).append( strAudio );
	        var audio = document.getElementById( "audioPlay" );

	        //浏览器支持 audion
	        audio.play();
	      }
	    };


function restaurants()
	    {
	      var borswer = window.navigator.userAgent.toLowerCase();
	      if ( borswer.indexOf( "ie" ) >= 0 )
	      {
	        //IE内核浏览器
	        var strEmbed = '<embed name="embedPlay" src="/Public/admin/mp3/cy.mp3" autostart="true" hidden="true" loop="false"></embed>';
	        if ( $( "body" ).find( "embed" ).length <= 0 )
	          $( "body" ).append( strEmbed );
	        var embed = document.embedPlay;

	        //浏览器不支持 audion，则使用 embed 播放
	        embed.volume = 100;
	        //embed.play();
	      } else
	      {
	        //非IE内核浏览器
	        var strAudio = "<audio id='audioPlay' src='/Public/admin/mp3/cy.mp3' hidden='true'>";
	        if ( $( "body" ).find( "audio" ).length <= 0 )
	          $( "body" ).append( strAudio );
	        var audio = document.getElementById( "audioPlay" );

	        //浏览器支持 audion
	        audio.play();
	      }
	    };


</script>

</body>
</html>