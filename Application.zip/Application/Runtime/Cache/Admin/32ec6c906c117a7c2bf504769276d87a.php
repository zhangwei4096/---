<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE HTML>
<html zh="zh-CN">
    <head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>管理系统</title>
		<meta name="description" content="管理系统">
		<meta name="keywords" content="管理系统">
		<link rel="icon" href="/Public/admin/images/favicon_16.ico">
		<link rel="shortcut icon" href="/Public/admin/images/favicon_16.ico"  type="image/x-icon">
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/bootstrap.min.css" />
		<link id="bootstrap-rtl-link" href="" rel="stylesheet" />
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/font-awesome.min.css" />
		<link  rel="stylesheet" type="text/css" href="/Public/admin/css/beyond.min.css" />
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/demo.min.css" />
		<link id="skin-link" href="" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="/Public/admin/css/boolw.css" />
		<script type="text/javascript" src="/Public/admin/js/jquery-2.0.3.min.js"></script>
		<script type="text/javascript" src="/Public/admin/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="/Public/admin/js/skins.min.js"></script>
		<script type="text/javascript" src="/Public/admin/js/slimscroll/jquery.slimscroll.min.js"></script>
		<script type="text/javascript" src="/Public/admin/js/boolw/jquery.boolw.js"></script>
		<!--[if lt IE 9]>
		<script type="text/javascript" src="/Public/admin/js/html5shiv.min.js"></script>
		<![endif]-->
</head>
<body>
<div class="login-container animated fadeInDown">
    <div class="loginbox bg-white">
		<form>
			<div class="loginbox-title">管理系统</div>
			<div class="loginbox-social">
				<div class="social-title "></div>
			</div>
			<div class="loginbox-or">
				<div class="or-line"></div>
				<div class="or">登录</div>
			</div>
			<div class="loginbox-textbox">
				<input type="text" name="username" class="form-control" placeholder="用户名" value="" />
			</div>
			<div class="loginbox-textbox">
				<input type="password" name="password" class="form-control" placeholder="密码" value="" />
			</div>
			<div class="loginbox-submit">
				<input type="button" class="btn btn-primary btn-block" value="Login" />
			</div>
		</form>
    </div>
    <div class="logobox">
        
    </div>
</div>
<script type="text/javascript">
	$(function(){
		$('input:button').click(function(){
			var name = $('input[name=username]').val();
			var pwd	 = $('input[name=password]').val();
			if(!(name=='' && pwd=='')){
				$.post("/index.php/admin/login/post_action",{name:name,pwd:pwd},function(data){
					if(data==1){
						//验证通过登录成功
						window.location.href='/index.php/admin/login/ok';
					}else{
						alert('用户名或密码错误');
						exit();
					}
				})
			}else{
				alert('用户名或密码不能为空');
				exit();
			}
				
		})
	})
</script>
<style type="text/css">
	@media (min-width: 768px){
		#modal-notice .modal-dialog{margin: 200px auto;}
	}
</style>
<!--Modal Templates-->
<!--LArge Modal Templates-->
<div class="modal fade" id="modal-add" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
		</div>
	</div>
</div>
<div class="modal fade" id="modal-edit" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
		</div>
	</div>
</div>
<div class="modal fade" id="modal-table" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
		</div>
	</div>
</div>
<div class="modal fade" id="iframe-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<iframe src="" border="0" frameborder="0" id="iframe-modal-dialog" scrolling="no" width="100%" height="90%"></iframe>
		</div>
		<button type="button" data-dismiss="modal" class="hidden" id="iframe-modal-close"></button>
	</div>
</div>
<!--End Large Modal Templates-->
<!--Success Modal Templates-->
<div id="modal-notice" class="modal modal-message fade" style="display: none;" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<i class="glyphicon glyphicon-check"></i>
			</div>
			<div class="modal-title">
				Success
			</div>
			<div class="modal-body">
				You have done great!
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-success" data-dismiss="modal">
					OK
				</button>
			</div>
		</div> 
	</div> 
</div>
<!--End Success Modal Templates-->
<!--End Modal Templates-->
<!--选择模态框关闭链接-->
<a href="#iframe-modal" _href="" data-toggle="modal" id="selected_iframe" data-target="#iframe-modal" class="hidden"></a>
<script type="text/javascript" src="/Public/admin/js/bootbox/bootbox.js"></script>
<script type="text/javascript" src="/Public/admin/js/boolw/modal.init.js"></script>
<script type="text/javascript" src="/Public/admin/js/beyond.js"></script>
<script type="text/javascript" src="/Public/admin/js/boolw.js"></script>
</body>
</html>