<?php
namespace Api\Controller;
use Common\Controller\HomeBaseController;
use Think\Model;
/**
 * 微信支付
 */
class WeixinpayController extends HomeBaseController{

    /**
     * notify_url接收页面
     */
    public function notify(){
        // 导入微信支付sdk
        vendor('Weixinpay.Weixinpay');
        vendor('Weixinpay.Wx');
        
        $wxpay   = new \Weixinpay();
        $wechat  = new \wx();   //自定义的类
        
        $result=$wxpay->notify();
        
	  #  $rs = './notify';

	  #  $xml=file_get_contents('php://input', 'r');
	  #  //转成php数组 禁止引用外部xml实体
    	  #  libxml_disable_entity_loader(true);
	  #  $data= json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA));
	  #  file_put_contents($rs, $data);
	
        if ($result) {
            // 验证成功 修改数据库的订单状态等 $result['out_trade_no']为订单号
            if ($result['attach']==1){
                //房间预订
                $User = new Model("Orders_room");
            }elseif ($result['attach']==2){
                //会议室预订
                $User = new Model("Orders_conference");
            }elseif ($result['attach']==3){
                //娱乐室预订
                $User = new Model("Orders_recreation");
            }elseif ($result['attach']==4){
                //餐饮预订
                $User = new Model("Orders_restaurant");
            }
            
            
            //$rs   = $wxpay->getUserInfo($result['openid']); //获取用户微信名称
            //$data['name']         = $rs['nickname'];
           
	        $out_trade_no = $result['out_trade_no'];
            $send         = $User->where("out_trade_no=$out_trade_no")->getField('send');
            
            
            if ($send==0){
                $find         = $User->where("out_trade_no=$out_trade_no")->find(); 
		        $access_token = $wechat->getAccessToken();
                $openid       = $result['openid'];
                $wechat->__send($access_token,$openid,$find); //发送通知
                //查询是否有对应用户的openID
               $data['openid'] = $User->table('qdh_openid')->where("openid='$openid'")->getField('id');  //查询出对应用户的ID
                
                if (empty($data['openid'])){
                    //如果没有就去查寻
		    $sql = 'INSERT INTO qdh_openid(`openid`) VALUES("'.$openid.'")';
                    $User->execute($sql);
                    $data['openid'] = $User->table('qdh_openid')->where("openid='$openid'")->getField('id');
                } 
            }
            
            $data['time_end']     = $result['time_end']; //支付完成时间
            $data['power']        = '0';  //业务状态为待处理   1为已接单  2为拒单
            $data['pay_state']    = '1'; //支付状态
            $data['send']         = '1'; //消息发送状态
            $User->where("out_trade_no=$out_trade_no")->save($data);
           
            
        }
    
    }

    /**
     * 公众号支付 必须以get形式传递 out_trade_no 参数
     * 示例请看 /Application/Home/Controller/IndexController.class.php
     * 中的weixinpay_js方法
     */
    
    public function pay_room(){
        //房间预订详细页面
        $User = new Model();
        $id   = I('get.id',1,intval);     //房间ID
        $out_trade_no = I('get.out_trade_no',1,intval);  //接收唯一表示ID
        
        $rs         = $User->table("qdh_orders_room")->where("out_trade_no=$out_trade_no")->find();
        $rs['date'] = $this->reckon($rs['out_time'], $rs['check_time']);  //入住天数
        $rs['room_price'] = $User->table("qdh_room")->where("id=$id")->getField('room_price');  //房间单价
        $rs['total_price']= $rs['data']*$rs['room_price']+$rs['price']; //房间总价
        $this->assign('data',$rs);
        $this->display();
    }
    
    
    public function pay_conference(){
        //会议室预订详细页面
        $User = new Model();
        $id   = I('get.id',1,intval);     //房间ID
        $out_trade_no = I('get.out_trade_no',1,intval);  //接收唯一表示ID
        
        $rs         = $User->table("qdh_orders_conference")->where("out_trade_no=$out_trade_no")->find();
        $conference = $User->table("qdh_conference")->where("id=$id")->find();
        $this->assign('data',$rs);
        $this->assign('conference',$conference);
        $this->display();
        
    }
    
    
    public function pay_recreation(){
        //娱乐室预订详细页面
        
        $User = new Model();
        $id   = I('get.id',1,intval);     //房间ID
        $out_trade_no = I('get.out_trade_no',1,intval);  //接收唯一表示ID
        $rs         = $User->table("qdh_orders_recreation")->where("out_trade_no=$out_trade_no")->find();
        $recreation = $User->table("qdh_recreation_room")->where("id=$id")->find();
        $this->assign('data',$rs);
        $this->assign('recreation',$recreation);
        $this->display();
    }
    
    
    public function pay_restaurant(){
        //餐饮预订详细页面
        
        $User = new Model();
        $id   = I('get.id',1,intval);     //房间ID
        $out_trade_no = I('get.out_trade_no',1,intval);  //接收唯一表示ID
        $rs         = $User->table("qdh_orders_restaurant")->where("out_trade_no=$out_trade_no")->find();
        $restaurant = $User->table("qdh_restaurant")->where("id=$id")->find();
        $this->assign('data',$rs);
        $this->assign('restaurant',$restaurant);
        $this->display();
    }
    
    
    public function pay(){
        // 导入微信支付sdk
        $out_trade_no = I('get.out_trade_no',1,intval);  //接收唯一表示ID
        vendor('Weixinpay.Weixinpay');
        $wxpay=new \Weixinpay();
        // 获取jssdk需要用到的数据
        $data=$wxpay->getParameters();
        // 将数据分配到前台页面
        $assign=array(
            'data'=>json_encode($data)
            );
        $this->assign($assign); 
        $this->display(); 
    }
    
    
    public function pay_ajax_post(){
        //ajax 异步方法
        $User = new Model();
        $id             = I("post.id");           //订单ID
        $data['name']   = $_POST['user_name'];  //用户名
        $data['phone']  = $_POST['phone'];   //电话号码
        $date                = $_POST['date']; //天数
        $data['room_number'] = $_POST['room_number'];  //房间数量
        $price               = $_POST['price'];   //定金
        $room_price          = $_POST['room_price'];   //房间单价
        $data['price']       = $data['room_number']*$price;  //房间数量*定金
        $data['total_price'] = $data['price']+$room_price*$data['room_number']*$date;  //总价=定金*房价数量+房价*天数*数量
            //$price = $User->table("qdh_orders_room")->where("id=$id")->getField('price');  //定金单价
        $result = $User->table('qdh_orders_room')->where("id=$id")->save($data);
         if ($result){
                echo 1;
            } 
    }
        

   public function conference_ajax_post(){
       //ajax 异步方法
       $User = new Model();
       $id             = I("post.id");           //订单ID
       $data['name']   = $_POST['user_name'];  //用户名
       $data['phone']  = $_POST['phone'];   //电话号码
       $result = $User->table('qdh_orders_conference')->where("id=$id")->save($data);
       if ($result){
           echo 1;
       }
       
   }
        

   
   public function recreation_ajax_post(){
       
       $User = new Model();
       $id             = I("post.id");           //订单ID
       $data['name']   = $_POST['user_name'];  //用户名
       $data['phone']  = $_POST['phone'];   //电话号码
       $result = $User->table('qdh_orders_recreation')->where("id=$id")->save($data);
       if ($result){
           echo 1;
       } 
   
   }
   
    
   
   public function restaurant_ajax_post(){
        
       $User = new Model();
       $id             = I("post.id");           //订单ID
       $data['name']   = $_POST['user_name'];  //用户名
       $data['phone']  = $_POST['phone'];   //电话号码
       $result = $User->table('qdh_orders_restaurant')->where("id=$id")->save($data);
       if ($result){
           echo 1;
       }
        
   }
    
   
   public  function reckon ($day1, $day2) {
       $second1 = strtotime($day1);
       $second2 = strtotime($day2);
   
       if ($second1 < $second2) {
           $tmp = $second2;
           $second2 = $second1;
           $second1 = $tmp;
       }
       return ($second1 - $second2) / 86400;
   }

}


