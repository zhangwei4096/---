<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Model;
use Think\Page;
class MainController extends Controller{
    
    public function _initialize(){
        //全局初始化
        session_start();
        header("Contet-Tyep:text/html;charset=UTF-8");
        if ($_SESSION['version'] != sha1(md5('*&^%$#@!'))){
            exit($this->error("请勿非法访问!",U('Index/index')));
        }
    }
    
    public function index(){
        //后台管理首页
        $this->display();
        
    }
    
    
    public function room_del(){
        //住房删除页面
        $this->admin_power();
        $User = new Model('Room');
        $id   = I('get.id','','strip_tags');//接收来自页面的ID 
        if($User->delete($id)){
            $this->success('删除数据成功');
            
        }else {
            $this->error('删除失败');
        }
        
    }
    
    
    public function room_list(){
        //房间展示方法
        $User = new Model('Room');
        $row = $User->getField('id,room_name,room_price,room_deposit,room_state');
        $this->assign('data',$row);
        $this->display();
    }
    
    
    public function conference_room_list(){
        //会议室展示方法
        $User = new Model('Conference');
        $row  = $User->getField('id,conference_name,conference_deposit,conference_price_max,conference_price_min,conference_state');
        $this->assign('data',$row);
        $this->display();
    }
    
    
    public function recreation_room_list(){
        //娱乐室展示方法
        $User = new Model('Recreation_room');
        $row  = $User->getField('id,recreation_name,recreation_price,recreation_deposit,recreation_state');
        //var_dump($row);
        $this->assign('data',$row);
        $this->display("servers_list1");
    }
    
    
    public function conference_del(){
        //会议室删除页面
        $this->admin_power();
        $User = new Model('Conference');
        $id   = I('get.id','','strip_tags');//接收来自页面的ID
        if($User->delete($id)){
            $this->success('删除数据成功');
    
        }else {
            $this->error('删除失败');
        }
    
    }
    
    public function recreation_room_del(){
        //娱乐房间删除页面
        $this->admin_power();
        $User = new Model('Recreation_room');
        $id   = I('get.id','','strip_tags');//接收来自页面的ID
        if($User->delete($id)){
            $this->success('删除数据成功');
        
        }else {
            $this->error('删除失败');
        }
        
    }
    
    
    public function restaurant_list(){
        //餐饮预订列表页面
        $User = new Model("Restaurant");
        $row  = $User->getField("id,restaurant_name,restaurant_price,restaurant_state");
        $this->assign('data',$row);
        $this->display("servers_list");
        
    }
    
    
    public function restaurant_del(){
        //餐饮删除
        $this->admin_power();
        $User = new Model('Restaurant');
        $id   = I('get.id','','strip_tags');//接收来自页面的ID
        if($User->delete($id)){
            $this->success('删除数据成功');
        
        }else {
            $this->error('删除失败');
        }
    }
    
    public function restaurant_edit(){
        $User = new Model("Restaurant");
        $id   = I('get.id','','strip_tags');//接收来自页面的ID
        $row  = $User->where("id=$id")->find();

        //图片分离操作
        $m_image =  explode('|', $row['restaurant_image_more']);
        $this->assign('m_image',$m_image);
        $this->assign('row',$row);
        $this->display();
        
        
    }
    
    
    public function restaurant_edit_post(){
        //餐饮修改方法
        $restaurant['restaurant_name']       = $_POST['user_type'];    //名字
        $restaurant['restaurant_price']      = $_POST['price'];   //半天价格
        $restaurant['restaurant_text']       = $_POST['id_card'];  //会议娱乐室文字简介
        $restaurant['restaurant_address']    = $_POST['address'];//地址
        $restaurant['restaurant_time']       = $_POST['time']; //容纳人数
        $restaurant['restaurant_day']        = $_POST['day']; //娱乐设施
        //接收需要修改操作的ID
        $User = new Model('Restaurant');
        $id   = I('get.id','','strip_tags');
        
        //取出图片组
        $more_images  = $User->where("id=$id")->getField('restaurant_image_more');  //取出图片数组
        $more_images  = explode('|', $more_images);
        
        
        //var_dump($_FILES);
        //图片上传操作
        if ( $_FILES['home_image']['tmp_name'][0] != null || $_FILES['more1_image']['tmp_name'][0] != null || $_FILES['more2_image']['tmp_name'][0] != null || $_FILES['more3_image']['tmp_name'][0] != null){
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     5242880 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath  =     './Public/images/'; // 设置附件上传根目录
            $upload->savePath  =     ''; // 设置附件上传（子）目录
            // 上传文件
            $info   =   $upload->upload();
            if(!$info) {// 上传错误提示错误信息
                $this->error($upload->getError());
            }else{// 上传成功
                $images  = Array();
                foreach($info as $file){
                    //echo $file['savepath'].$file['savename'].'</br>';
                    // $images[] = $file['savepath'].$file['savename'];
                    $result = '/images/'.$file['savepath'].$file['savename'];
        
                    ///判断传递过来的图片input属性
                    switch ($file['key']){
                        case more1_image:
                            unset($more_images[0]);
                            $more_images[0]    =  $result;
                            break;
                        case more2_image:
                            unset($more_images[1]);
                            $more_images[1]    =  $result;
                            break;
                        case more3_image:
                            unset($more_images[2]);
                            $more_images[2]    =  $result;
                             
                            break;
                        case home_image:
                            $image_home        =  $result;
                            break;
                    }
        
        
                }
        
                //var_dump($more_images);
        
                $restaurant['restaurant_image_more'] =  implode("|",$more_images); //数据转化为字符串
        
                if (!empty($image_home)){
                    //判断首页是否为空
                    $restaurant['restaurant_image_home'] =  $image_home;
                }
        
            }
        
        }
        
        if($User->where("id=$id")->save($restaurant)){
            $this->success('修改成功');
        }else {
            $this->error('修改失败');
        }
        
        
        
        
    }
    
    
    public function restaurant_state_post(){
        //餐饮异步状态
        $User = new Model('Restaurant');
        $id   = I('post.id','','strip_tags');
        //执行状态修改
        $state = $User->where("id=$id")->getField('restaurant_state');
        
        switch ($state){
            case 0:
                $change['restaurant_state'] = 1;
                break;
            default:
                $change['restaurant_state'] = 0;
        }
        
        if ($User->where("id=$id")->save($change)){
            echo 1;
        }
        
        
    }
    
    
    
    
    
    
    
    
    public function recreation_room_edit(){
        //娱乐房间修改页面
        $User = new Model('Recreation_room');
        $id   = I('get.id','','strip_tags');
        $row  = $User->where("id=$id")->find();
        
        //图片分离操作
        $m_image =  explode('|', $row['recreation_image_more']);
        $this->assign('m_image',$m_image);
        $this->assign('row',$row);
        $this->display();
        
    }
    
    public function recreation_edit_post(){
        //娱乐室修改方法
        $recreation['recreation_name']       = $_POST['user_type']; //房间名称
        $recreation['recreation_price']      = $_POST['price'];  //价格
        $recreation['recreation_text']       = $_POST['id_card']; //简介
        $recreation['recreation_mx']         = $_POST['vip_card'];  //面积
        $recreation['recreation_people']     = $_POST['number'];   //可住人数
        $recreation['recreation_bath']       = $_POST['receipt_no'];   //沐浴设施
        $recreation['recreation_deposit']    = $_POST['d_price']; //定金
        //接收需要修改操作的ID
        $User = new Model('Recreation_room');
        $id   = I('get.id','','strip_tags');
        
        //取出图片组
        $more_images  = $User->where("id=$id")->getField('recreation_image_more');  //取出图片数组
        $more_images  = explode('|', $more_images);
        
        
        //var_dump($_FILES);
        //图片上传操作
        if ( $_FILES['home_image']['tmp_name'][0] != null || $_FILES['more1_image']['tmp_name'][0] != null || $_FILES['more2_image']['tmp_name'][0] != null || $_FILES['more3_image']['tmp_name'][0] != null){
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     5242880 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath  =     './Public/images/'; // 设置附件上传根目录
            $upload->savePath  =     ''; // 设置附件上传（子）目录
            // 上传文件
            $info   =   $upload->upload();
            if(!$info) {// 上传错误提示错误信息
                $this->error($upload->getError());
            }else{// 上传成功
                $images  = Array();
                foreach($info as $file){
                    //echo $file['savepath'].$file['savename'].'</br>';
                    // $images[] = $file['savepath'].$file['savename'];
                    $result = '/images/'.$file['savepath'].$file['savename'];
        
                    ///判断传递过来的图片input属性
                    switch ($file['key']){
                        case more1_image:
                            unset($more_images[0]);
                            $more_images[0]    =  $result;
                            break;
                        case more2_image:
                            unset($more_images[1]);
                            $more_images[1]    =  $result;
                            break;
                        case more3_image:
                            unset($more_images[2]);
                            $more_images[2]    =  $result;
                             
                            break;
                        case home_image:
                            $image_home        =  $result;
                            break;
                    }
        
        
                }
        
                //var_dump($more_images);
        
                $recreation['recreation_image_more'] =  implode("|",$more_images); //数据转化为字符串
        
                if (!empty($image_home)){
                    //判断首页是否为空
                    $recreation['recreation_image_home'] =  $image_home;
                }
        
            }
        
        }
        
        if($User->where("id=$id")->save($recreation)){
            $this->success('修改成功');
        }else {
            $this->error('修改失败');
        }
        
        
        
    }
    
    public function room_edit(){
        //房间修改
        $User = new Model('Room');
        $id   = I('get.id','','strip_tags');
        $row  = $User->where("id=$id")->find();
    
        //图片分离操作
        $m_image =  explode('|', $row['room_image_more']);
        $this->assign('m_image',$m_image);
        $this->assign('row',$row);
        $this->display();
    }
    
    
    public function room_edit_post(){
        //房间修改方法
        $room['room_name']       = $_POST['user_type']; //房间名称
        $room['room_price']      = $_POST['name'];  //价格
        $room['room_text']       = $_POST['id_card']; //简介
        $room['room_mx']         = $_POST['vip_card'];  //面积
        $room['room_people']     = $_POST['number'];   //可住人数
        $room['room_bath']       = $_POST['receipt_no'];   //沐浴设施
        $room['room_deposit']    = $_POST['d_pirce']; //定金
        //接收需要修改操作的ID
        $User = new Model('Room');
        $id   = I('get.id','','strip_tags'); 
        
        //取出图片组
        $more_images  = $User->where("id=$id")->getField('room_image_more');  //取出图片数组
        $more_images  = explode('|', $more_images);
        
        
        //var_dump($_FILES);
        //图片上传操作
        if ( $_FILES['home_image']['tmp_name'][0] != null || $_FILES['more1_image']['tmp_name'][0] != null || $_FILES['more2_image']['tmp_name'][0] != null || $_FILES['more3_image']['tmp_name'][0] != null){
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize   =     5242880 ;// 设置附件上传大小
        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->rootPath  =     './Public/images/'; // 设置附件上传根目录
        $upload->savePath  =     ''; // 设置附件上传（子）目录
        // 上传文件
        $info   =   $upload->upload();
        if(!$info) {// 上传错误提示错误信息
            $this->error($upload->getError());
        }else{// 上传成功
            $images  = Array();
            foreach($info as $file){
                //echo $file['savepath'].$file['savename'].'</br>';
                // $images[] = $file['savepath'].$file['savename'];
                $result = '/images/'.$file['savepath'].$file['savename'];
        
                ///判断传递过来的图片input属性
                switch ($file['key']){
                    case more1_image:
                        unset($more_images[0]);
                        $more_images[0]    =  $result;
                        break;
                    case more2_image:
                        unset($more_images[1]);
                        $more_images[1]    =  $result;
                        break;
                    case more3_image:
                        unset($more_images[2]);
                        $more_images[2]    =  $result;
                         
                        break;
                    case home_image:
                        $image_home        =  $result;
                        break;
                }
        
        
            }
        
            //var_dump($more_images);
        
            $room['room_image_more'] =  implode("|",$more_images); //数据转化为字符串
            
            if (!empty($image_home)){
                //判断首页是否为空
            $room['room_image_home'] =  $image_home;
            }
        
        }
        
      } 
      
          if($User->where("id=$id")->save($room)){
              $this->success('修改成功');
          }else {
              $this->error('修改失败');
          }
      
    }
    
    
    public function room_state_post(){
        //是否停止订房状态异步方法
        $User = new Model('Room');
        $id   = I('post.id','','strip_tags');
        //执行状态修改
        $state = $User->where("id=$id")->getField('room_state');

        switch ($state){
            case 0:
                $change['room_state'] = 1;
                break;
            default:
                $change['room_state'] = 0;
        }
        
        if ($User->where("id=$id")->save($change)){
            echo 1;
        }
    }
    
    
    
    public function recreation_state_post(){
        //是否停止订预订娱乐室
        $User = new Model('Recreation_room');
        $id   = I('post.id','','strip_tags');
        //执行状态修改
        $state = $User->where("id=$id")->getField('recreation_state');
        
        switch ($state){
            case 0:
                $change['recreation_state'] = 1;
                break;
            default:
                $change['recreation_state'] = 0;
        }
        
        if ($User->where("id=$id")->save($change)){
            echo 1;
        }
    }
    
    
    public function conference_state_post(){
        //是否停止订房状态异步方法
        $User = new Model('Conference');
        $id   = I('post.id','','strip_tags');
        //执行状态修改
        $state = $User->where("id=$id")->getField('conference_state');
    
        switch ($state){
            case 0:
                $change['conference_state'] = 1;
                break;
            default:
                $change['conference_state'] = 0;
        }
    
        if ($User->where("id=$id")->save($change)){
            echo 1;
        }
    }
    
    
    
    /*
     * 房间添加方法
     *   
     *   */
    
    public function room_add_post(){
        $room['room_name']       = $_POST['user_type']; //房间名称
        $room['room_price']      = $_POST['name'];  //价格
        $room['room_text']       = $_POST['id_card']; //简介
        $room['room_mx']         = $_POST['vip_card'];  //面积
        $room['room_people']     = $_POST['number'];   //可住人数
        $room['room_bath']       = $_POST['receipt_no'];   //沐浴设施
        $room['room_deposit']    = $_POST['d_pirce']; //定金
        
        $image = $this->image_upload();//图片处理
        
        $room['room_image_home'] = $image['home'];
        $room['room_image_more'] = $image['more'];
        
        $User = new Model("Room");
        if ($User->add($room)){
            $this->success('添加成功');
        }else {
            $this->error('添加失败，请重试');
        }
    }
    
    
    /* 
     * 会议室添加方法
     *  
     *  */
    
    public function conference_add_post(){
         $conference['conference_name']       = $_POST['user_type'];    //名字
         $conference['conference_price_max']  = $_POST['max_price'];   //半天价格
         $conference['conference_price_min']  = $_POST['min_price'];  //全天价格
         $conference['conference_deposit']    = $_POST['d_price'];   //定金
         $conference['conference_text']       = $_POST['id_card'];  //会议娱乐室文字简介
         $conference['conference_mx']         = $_POST['vip_card'];//面积
         $conference['conference_people']     = $_POST['number']; //容纳人数
         $conference['conference_bath']       = $_POST['receipt_no']; //娱乐设施
       
         $image = $this->image_upload(); //图片处理
         
         $conference['conference_image_home'] = $image['home'];
         $conference['conference_image_more'] = $image['more'];
         
         $User = new Model('Conference');
         if ($User->add($conference)){
             $this->success('添加成功');
         }else {
             $this->error('添加失败，请重试');
         }
         
         
    }
    
    
    /*
     * 
     * 娱乐室添加方法
     * @2017-12-13
     */
    
    public function recreation_room_add(){
        $recreation['recreation_name']       = $_POST['user_type'];    //名字
        $recreation['recreation_price']      = $_POST['price'];   //半天价格
        $recreation['recreation_deposit']    = $_POST['d_price'];   //定金
        $recreation['recreation_text']       = $_POST['id_card'];  //会议娱乐室文字简介
        $recreation['recreation_mx']         = $_POST['vip_card'];//面积
        $recreation['recreation_people']     = $_POST['number']; //容纳人数
        $recreation['recreation_bath']       = $_POST['receipt_no']; //娱乐设施
         
        $image = $this->image_upload(); //图片处理
         
        $recreation['recreation_image_home'] = $image['home'];
        $recreation['recreation_image_more'] = $image['more'];
         
        $User = new Model('Recreation_room');
        if ($User->add($recreation)){
            $this->success('添加成功');
        }else {
            $this->error('添加失败，请重试');
        }
        
    }
    
    /*
     *
     * 餐厅添加方法
     * @2017-12-13
     */
    
    
    public function restaurant_room_add(){
        $restaurant['restaurant_name']       = $_POST['user_type'];    //名字
        $restaurant['restaurant_price']      = $_POST['price'];   //半天价格
        //$restaurant['restaurant_deposit']    = $_POST['d_price'];   //定金
        $restaurant['restaurant_text']       = $_POST['id_card'];  //会议娱乐室文字简介
        $restaurant['restaurant_address']    = $_POST['address'];//地址
        $restaurant['restaurant_time']       = $_POST['time']; //容纳人数
        $restaurant['restaurant_day']        = $_POST['day']; //娱乐设施
         
        $image = $this->image_upload(); //图片处理
         
        $restaurant['restaurant_image_home'] = $image['home'];
        $restaurant['restaurant_image_more'] = $image['more'];
         
        $User = new Model('Restaurant');
        if ($User->add($restaurant)){
            $this->success('添加成功');
        }else {
            $this->error('添加失败，请重试');
        }
    }
    
    
    /* 
     * 
     * 会议室修改
     *  
     *  */
    
    public function conference_room_edit(){
        $User = new Model('Conference');
        $id   = I('get.id','','strip_tags');
        $row  = $User->where("id=$id")->find();
    
        //图片分离操作
        $m_image =  explode('|', $row['conference_image_more']);
        $this->assign('m_image',$m_image);
        $this->assign('row',$row);
        $this->display();
    }
    
    public function conference_edit_post(){
         $conference['conference_name']       = $_POST['user_type'];    //名字
         $conference['conference_price_max']  = $_POST['max_price'];   //忙时价格
         $conference['conference_price_min']  = $_POST['min_price'];  //闲时价格
         $conference['conference_deposit']    = $_POST['d_price'];   //定金
         $conference['conference_text']       = $_POST['id_card'];  //会议娱乐室文字简介
         $conference['conference_mx']         = $_POST['vip_card'];//面积
         $conference['conference_people']     = $_POST['number']; //容纳人数
         $conference['conference_bath']       = $_POST['receipt_no']; //娱乐设施
        //接收需要修改操作的ID
        $User = new Model('Conference');
        $id   = I('get.id','','strip_tags');
        
        //取出图片组
        $more_images  = $User->where("id=$id")->getField('conference_image_more');  //取出图片数组
        $more_images  = explode('|', $more_images);
        
        
        //var_dump($_FILES);
        //图片上传操作
        if ( $_FILES['home_image']['tmp_name'][0] != null || $_FILES['more1_image']['tmp_name'][0] != null || $_FILES['more2_image']['tmp_name'][0] != null || $_FILES['more3_image']['tmp_name'][0] != null){
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     5242880 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath  =     './Public/images/'; // 设置附件上传根目录
            $upload->savePath  =     ''; // 设置附件上传（子）目录
            // 上传文件
            $info   =   $upload->upload();
            if(!$info) {// 上传错误提示错误信息
                $this->error($upload->getError());
            }else{// 上传成功
                $images  = Array();
                foreach($info as $file){
                    //echo $file['savepath'].$file['savename'].'</br>';
                    // $images[] = $file['savepath'].$file['savename'];
                    $result = '/images/'.$file['savepath'].$file['savename'];
        
                    ///判断传递过来的图片input属性
                    switch ($file['key']){
                        case more1_image:
                            unset($more_images[0]);
                            $more_images[0]    =  $result;
                            break;
                        case more2_image:
                            unset($more_images[1]);
                            $more_images[1]    =  $result;
                            break;
                        case more3_image:
                            unset($more_images[2]);
                            $more_images[2]    =  $result;
                             
                            break;
                        case home_image:
                            $image_home        =  $result;
                            break;
                    }
        
        
                }
        
                //var_dump($more_images);
        
                $conference['conference_image_more'] =  implode("|",$more_images); //数据转化为字符串
        
                if (!empty($image_home)){
                    //判断首页是否为空
                    $conference['conference_image_home'] =  $image_home;
                }
        
            }
        
        }
        
        if($User->where("id=$id")->save($conference)){
            $this->success('修改成功');
        }else {
            $this->error('修改失败');
        }
        
        
    }
    
    private  function image_upload(){
        
        //图片上传操作
        $upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize   =     5242880 ;// 设置附件上传大小
        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->rootPath  =     './Public/images/'; // 设置附件上传根目录
        $upload->savePath  =     ''; // 设置附件上传（子）目录
        // 上传文件
        $info   =   $upload->upload();
        if(!$info) {// 上传错误提示错误信息
            $this->error($upload->getError());
        }else{// 上传成功
            $images  = Array();
            foreach($info as $file){
                //echo $file['savepath'].$file['savename'].'</br>';
                 
                // $images[] = $file['savepath'].$file['savename'];
                $result = '/images/'.$file['savepath'].$file['savename'];
                 
                 
                ///判断传递过来的图片input属性
                switch ($file['key']){
                    case more1_image:
                        $images['0']    =  $result;
                        break;
                    case more2_image:
                        $images['1']    =  $result;
                        break;
                    case more3_image:
                        $images['2']    =  $result;
                        break;
                    case home_image:
                        $image_home     =  $result;
                        break;
                }
                 
                 
            }
             
             
            $image['more'] =  implode("|",$images); //数据转化为字符串
            $image['home'] = $image_home;
            return  $image;
        }
        
        
    }
    
    
    
    
    
    
    public function admin_list(){
        //管理员列表
        $User = new Model('Root');
        $row  = $User->select(); 
        $this->assign('data',$row);
        $this->display();
    }

    public function admin_edit(){
        //管理员账户修改页面
        $id = I('get.id');
        $this->assign('id',$id);
        $this->display();
    }

    public function edit_passwd(){
        //管理员密码修改
        $this->admin_power();
        $User = new Model('Root');
        $id   = I('post.id'); 
        $oldpwd = sha1(md5(I("post.oldpwd")));
        $data['root_passwd'] = sha1(md5(I("post.newpwd")));
        
        $passwd = $User->where("id=$id")->getField('root_passwd');
        
        if($oldpwd!=$passwd){
            echo 0;
        }else {
          $result = $User->where("id=$id")->save($data);
          if ($result){
              echo 1;
          }
          
        }
        
    }

    public function orders_list(){
        //客房预订方法
        $User = new Model('Orders_room');
        $this->__slef($User);
    }

    
    

    public function orders_list1(){
        //会议室预订方法
        $User   = new Model('Orders_conference');
         $this->__slef($User);
    }

    
    public function orders_list2(){
        //会议室信息备注页面
        $text['room']  = I("get.room");  //房间类型 1为会议室2为娱乐室
        switch ($text['room'] ){
            case '1':
                $User  = new Model('Orders_conference');
                break;
            case '2':
                $User  = new Model('Orders_recreation');
                break;
            case '3':
                $User  = new Model('Orders_restaurant');
        }
        
        $text['id']     = I("get.id");
        $text['text']   = $User->where('id="'.$text['id'].'"')->getField("text");
        $this->assign('text',$text);
        $this->display();
    }
    
    
    public function  edit_conference_and_recreation(){
        //会议室和娱乐室信息备注异步页面
        $room    = I("post.room");
        switch ($room){
            case '1':
                $User  = new Model('Orders_conference');
                break;
            case '2':
                $User  = new Model('Orders_recreation');
                break;
            case '3':
                $User  = new Model('Orders_restaurant');
        }
        
        $data['id']      = I('post.id');
        $data['text']    = I('post.text');
        if ($User->save($data)){
            echo 1;
        }
    }
    

    public function orders_list3(){
        //娱乐室预订页面
        $User   = new Model('Orders_recreation');
        $this->__slef($User);
    }
    
    
    public function orders_list4(){
        //餐饮预订页面
        $User   = new Model('Orders_restaurant');
        $this->__slef($User);
    }
    
    
    
    
    
    public function orders_post(){
        //订单提醒功能
        $User = new Model();
        $result1 = $User->table("qdh_orders_room")->where("send='1'")->find();
        $result2 = $User->table("qdh_orders_conference")->where("send='1'")->find();
        $result3 = $User->table("qdh_orders_recreation")->where("send='1'")->find();
        $result4 = $User->table("qdh_orders_restaurant")->where("send='1'")->find();
       # if (!empty($result1['id']||$result2['id']||$result3['id']||$result4['id'])){
        #    echo 1;
        #}
	 $data = array();

        if (!empty($result1['id'])) {
            $data['room'] = $result1['id'];
        }

        if (!empty($result2['id'])) {
             $data['conference'] = $result2['id'];

        }
        
        if (!empty($result3['id'])) {
             $data['recreation'] = $result3['id'];

        }
        
        if (!empty($result4['id'])) {
             $data['restaurant'] = $result4['id'];

        }
        
	echo json_encode($data);

    }
    
   	public function test(){

	
	
	$this->display();
	} 
   


 public function end_room(){
        $User = new Model('Orders_room');
        $data['send']  = '2';
        if ($User->where("send='1'")->save($data)){
            echo 1;
        }
    }
    
    public function end_conference(){
        $User = new Model('Orders_conference');
        $data['send']  = '2';
        if ($User->where("send='1'")->save($data)){
            echo 1;
        }
    }
    
    
    public function end_recreation(){
        $User = new Model('Orders_recreation');
        $data['send']  = '2';
        if ($User->where("send='1'")->save($data)){
            echo 1;
        }
        
    }
    
    public function end_restaurant(){
        $User = new Model('Orders_restaurant');
        $data['send']  = '2';
        if ($User->where("send='1'")->save($data)){
            echo 1;
        }
    
    }
    
    
    public function orders_state_edit(){
        //接单状态改变
        $room = I("post.room");  //要操作的房间
        $id   = I('post.id');
        switch ($room){
            case 1:
                $User  = new Model('Orders_room');
                break;
            case 2:
                $User  = new Model('Orders_conference');
                break;
            case 3:
                $User  = new Model('Orders_recreation');
                break;
            case 4:
                $User  = new Model('Orders_restaurant');
        }
        
        $result = $User->where("id=$id")->getField('power');  //获取当前的状态
        
        
        if ($result !=''){    
            switch ($result){
                    case 0:
                        $data['power'] = '1';
                        if ($User->where("id=$id")->save($data)){
                            echo 1;
                        }
                        break;
                    case 1:
                        echo 2;
                        break;
             } 
        }
        
    }
    
    
    public function refund(){
        //商户拒单退款操作
        $User = new Model('Orders_room'); 
        $id   = I('get.id');
        $result = $User->where("id=$id")->find();
        $this->assign('result',$result);
        $this->display();
    }
    
    
    
    public function refund_post(){
        $uri = "http://wx.veimx.com/Wx/example/refund.php";//这里换成自己的服务器的地址
        // 参数数组
        
        $out_trade_no = I('post.out_trade_no');
        $total_fee    = I('post.total_fee')*100;
        $refund_fee   = I('post.refund_fee')*100;
        $data = array (
            'out_trade_no' =>  $out_trade_no,
            'total_fee'    =>  $total_fee,
            'refund_fee'   =>  $refund_fee
        );
        
        $ch = curl_init ();
        // print_r($ch);
        curl_setopt ( $ch, CURLOPT_URL, $uri );
        curl_setopt ( $ch, CURLOPT_POST, 1 );
        curl_setopt ( $ch, CURLOPT_HEADER, 0 );
        curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
        curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
        $return = curl_exec ( $ch );
        curl_close ( $ch );
        $return =  json_decode($return,true);
        $this->refund_update($return,$out_trade_no);  //吧值传递个下一个处理
    }
    
    
    
    
    
    ///////////////////////////私有方法建议不要动///////////////////////////////////////////////////
    
    private function refund_update($return,$out_trade_no){
        $User = new Model('Orders_room');
    
        if ($return['return_msg']=='OK' && $return['return_code'] == 'SUCCESS' && $return['result_code']== 'SUCCESS'){
            $sql = "UPDATE qdh_orders_room SET `power`= '2' WHERE out_trade_no=$out_trade_no ";
            $User->execute($sql);
            echo 1;
        }else {
            echo 2;
        }
    
    }
    
    
    private function __slef($User){
        //订单页面统一方法
        $search = $_GET['search'];
        $radio  = $_GET['radios'];  //接收来自页面的查询类型
        $page   = $this->___page($User,10,$radio);
        $show   = $this->__show($page);
        if (!empty($search)){
            $result = $User->where("phone='$search'")->order('id desc')->limit($page->firstRow.','.$page->listRows)->select();
        
        }
        
        if (!empty($radio)){
            $result  =   $this->switchs($radio,$User,$page);
        }
        
        $this->assign('data',$result);
        $this->assign('radio',$radio);
        $this->assign('page',$show);
        $this->display();
        
    }
    
    
    
    
    
    
    private function  ___page($User,$totel,$radio){
        
        switch ($radio){

            case 1:
                $count = $User->count(id);
                break;
            case 2:
                $count = $User->where("power = '0'")->count(id);
                break;
            case 3:
                $count = $User->where("power = '1'")->count(id);
                break;
            case 4:
                $count = $User->where("power = '2' OR power='3'")->count(id);
                break;
            case 5:
                $count = $User->where("pay_state = '0'")->count(id);
                break;
            case 6:
                $date = date("Y-m-d"); //今日
                $count = $User->where("check_time >= '$date' AND power = '1'")->count(id);
                break;
            case 7:
                $date = date("Y-m-d"); //今日
                $count = $User->where("check_time = '$date' AND power = '1'")->count(id);
                break;
            case 8:     
                $date = date("Ymd"); //今日
                $count = $User->where("time_end LIKE '$date%' AND pay_state = '1'")->count(id);
                break;
            
        }
        
        
        $page  = new  Page($count,$totel); //每页显示多少商品
        return $page;
         
    }
    
    private function __show($page){
        $show  = $page->setConfig('first', '首页');
        $show  = $page->setConfig('prev', '上一页');
        $show  = $page->setConfig('next', '下一页');
        $show  = $page->setConfig('last', '尾页');
        $show  = $page->show();
        return $show;
    }
    
    
    
    private function switchs($radio,$User,$page){
    
        switch ($radio){
            case "1":
                //这儿是全部订单的页面
                $result = $User->order('id desc')->limit($page->firstRow.','.$page->listRows)->select();
                break;
            case "2":
                //这儿是待处理订单的页面
                $result = $User->where("power = '0'")->order('id desc')->limit($page->firstRow.','.$page->listRows)->select();
                break;
            case "3":
                //这儿是已接单订单的页面
                $result = $User->where("power = '1'")->order('id desc')->limit($page->firstRow.','.$page->listRows)->select();
                break;
            case "4":
                //这儿是已拒单订单的页面
                $result = $User->where("power = '2' OR power = '3'")->order('id desc')->limit($page->firstRow.','.$page->listRows)->select();
                break;
            case "5":
                //这儿是已取消订单的页面
                $result = $User->where("pay_state = '0'")->order('id desc')->limit($page->firstRow.','.$page->listRows)->select();
                break;
            case "6":
                //这儿是待入住的订单的页面
                //$date = date("Y-m-d",strtotime("+1 day"));  //明日以后入住的订单
                $date = date("Y-m-d"); //今日
                $result = $User->where("check_time >= '$date' AND power = '1' ")->order('id desc')->limit($page->firstRow.','.$page->listRows)->select();
                break;
            case "7":
                //这儿是今日入住的订单的页面
                $date = date("Y-m-d"); //今日
                $result = $User->where("check_time = '$date' AND power = '1' ")->order('id desc')->limit($page->firstRow.','.$page->listRows)->select();
                break;
            case "8":
                //这儿是今日新订的订单的页面
                $date = date("Ymd"); //今日
                $result = $User->where("time_end LIKE '$date%' AND pay_state = '1'")->order('id desc')->limit($page->firstRow.','.$page->listRows)->select();
                break;
        }
        return $result;
    }
    
    
    private function admin_power(){
        //验证是否为管理员
        if ($_SESSION['admin_power']=='1'){
            $this->error('您无权操作此项，请联系您的管理员!!谢谢');
            exit();
        }
        
    }
    
    ///////////////////////////私有方法建议不要动///////////////////////////////////////////////////
    
    
}

