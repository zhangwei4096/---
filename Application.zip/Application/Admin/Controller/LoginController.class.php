<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Model;
class LoginController extends Controller{
    
    public function index(){
        $this->display();
    }
    
    public function post_action(){
        $User = new Model('Root');
        $name = I('post.name','','strip_tags'); //用户名
        $pwd  = sha1(md5(I('post.pwd','','strip_tags'))); //用户密码
        if (!empty($name && $pwd)){
            $result = $User->where("root_user='$name'")->find();
            if ($pwd==$result['root_passwd']){
                //验证成功  开启session
                session_start();
                $_SESSION['admin_power'] = $result['root_state'];
                $_SESSION['name']        = $name;
                $_SESSION['version']     = sha1(md5('*&^%$#@!'));
                echo 1;
                exit();
            }
        }
            echo 0;
        
    }
    
    public function ok(){
        session_start();
        if ($_SESSION['version']){
            $this->success("欢迎您超级管理员",U('Main/index'));
        }
    }
    
    public function logout(){
        //退出登录 注销session操作
        session('[destroy]');
        $this->redirect('/Admin/index/index');
    }
    
}
