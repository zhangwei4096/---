<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        $this->redirect('Login/index'); //页面重定向
    }
}