<?php
return array(
	//'配置项'=>'配置值'
	'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'qdh_hotel', //数据库名字
    'DB_USER' => 'root',
    'DB_PWD'  => '199665zw',
    'DB_PORT' => 3306,
    'DB_PARAMS' =>  array(), // 数据库连接参数
    'DB_PREFIX' => 'qdh_', // 数据库表前缀
    'DB_CHARSET'=> 'utf8', // 字符集
    'DB_DEBUG'  =>  False, // 数据库调试模式 开启后可以记录SQL日志
    'SHOW_PAGE_TRACE'     =>  False, //调试模式
    'DEFAULT_MODULE'        =>  'Home',  // 默认模块
    'DEFAULT_CONTROLLER'    =>  'Index',
    'URL_HTML_SUFFIX'       => '',
    'DEFAULT_FILTER'    =>  'strip_tags,stripslashes',  //特殊字符过滤处理
    
    'WEIXINPAY_CONFIG'       => array(
       'APPID'              => 'wx9d28a30c8da10ddd', // 微信支付APPID
        'MCHID'              => '1411206102', // 微信支付MCHID 商户收款账号
        'KEY'                => 'qwertyuioppoiuytrewq123456789qwe', // 微信支付KEY
        'APPSECRET'          => 'e05115ba2890fd433586d30f89b3cfcb',  //公众帐号secert
        'NOTIFY_URL'         => 'http://wx.veimx.com/index.php/Api/WeixPay/notify/', // 接收支付状态的连接  改成自己的域名
    ),
);
