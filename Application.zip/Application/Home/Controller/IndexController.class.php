<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model;
class IndexController extends Controller {
    
    public function _initialize(){
        session_start();
        date_default_timezone_set('Asia/Shanghai');
    }
    
    public function lists(){ //客房展示页面
        $User = new Model('Room');
        $chcke_time = I('post.chcke_time'); //入住时间
        $out_time   = I('post.out_time'); //离店时间
        $man        = I('post.man'); //入住多少人
        
        $_SESSION['user_info'] =array(
          'chcke_time' => $chcke_time,
          'out_time'  => $out_time,
          'man'       => $man
        ); 
        
        $row   = $User->getField('id,room_name,room_image_home,room_state');
        $this->assign('data',$row);
        $this->display();
    }
    
    public function moyy(){//客房详细页面
        $User = new Model('Room');
        $id   = I('get.id','','strip_tags');//接收来自页面的ID
        $row  = $User->where("id=$id")->find();
        $more_image = explode('|', $row['room_image_more']); 
        //var_dump($more_image);
        $this->assign('data',$row);
        $this->assign('images',$more_image);
        $this->display();
    }
    
    
    
    
    
    public function hysyd(){
        //会议室展示页面
        $User = new Model('Conference');
        $row   = $User->getField('id,conference_name,conference_image_home,conference_state');
        //var_dump($row);
        $this->assign('data',$row);
        $this->display();
    }
    
    public function hysxd(){
        //会议室详细页面
        $User = new Model('Conference');
        $id   = I('get.id','','strip_tags');//接收来自页面的ID
        $row  = $User->where("id=$id")->find();
        $more_image = explode('|', $row['conference_image_more']);
        //var_dump($row);
        $this->assign('row',$row);
        $this->assign('images',$more_image);
        $this->display();
    }

    
    public function cyyd(){
        //餐饮详细页面
        $User = new Model('Restaurant');
        $row   = $User->getField('id,restaurant_name,restaurant_image_home,restaurant_state');
        //var_dump($row);
        $this->assign('data',$row);
        $this->display();
        
    }
    
    public function cyxd(){
        //餐饮下单页面
        $User = new Model('Restaurant');
        $id   = I('get.id','','strip_tags');//接收来自页面的ID
        $row  = $User->where("id=$id")->find();
        $more_image = explode('|', $row['restaurant_image_more']);
        //var_dump($row);
        $this->assign('row',$row);
        $this->assign('images',$more_image);
        $this->display();
    }
    
    
    
    public function ylsyd(){
        //餐饮详细页面
        $User = new Model('Recreation_room');
        $row   = $User->getField('id,recreation_name,recreation_image_home,recreation_state');
        //var_dump($row);
        $this->assign('data',$row);
        $this->display();
    
    }
    
    public function ylsxd(){
        //餐饮下单页面
        $User = new Model('Recreation_room');
        $id   = I('get.id','','strip_tags');//接收来自页面的ID
        $row  = $User->where("id=$id")->find();
        $more_image = explode('|', $row['recreation_image_more']);
        //var_dump($row);
        $this->assign('row',$row);
        $this->assign('images',$more_image);
        $this->display();
    }
    
    
    
    public function judge(){
        //判断房间是否已经停止订购
        $User  = new Model();
        $id    = I('post.id');
        $state = I('post.state');
        if ($state==1){
            $result = $User->table('qdh_room')->where("id=$id")->getField('room_state');
        }elseif ($state==2){
            $result = $User->table('qdh_conference')->where("id=$id")->getField('conference_state');
        }elseif($state==3){
            //娱乐室
            $result = $User->table('qdh_recreation_room')->where("id=$id")->getField('recreation_state');
        }elseif($state==4){
            //餐饮
            $result = $User->table('qdh_restaurant')->where("id=$id")->getField('restaurant_state');
        }
        
        echo $result;
    }
    
    
    
    public function historylists(){
        //获取用户的openID值
        vendor('Weixinpay.Weixinpay');
        $User = new Model();
        $wx   = new \Weixinpay();
        $openid = $wx->getopenid();
        
        $_SESSION['openid'] = $User->table('qdh_openid')->where("openid='$openid'")->getField('id');
        if ($_SESSION['openid']){
            $this->success('用户身份验证成功',U('Index/get_user_info?orders=1'));
        }else {
            $this->error('您还没有下过任何订单');
            exit();
        }
    }
    
    public function get_user_info(){
        //获取用户的订单
        $User = new Model();
        $openid = $_SESSION['openid'];
        $orders = I('get.orders');
        
        switch ($orders){
            case '1':
                $orders_room = $User->table('qdh_orders_room')->where("openid='$openid' AND pay_state='1'")->order("time_end desc")->select();
                
                foreach ($orders_room as $key => $val){
                     
                    //$time_end = substr($val['time_end'],0,8); //支付时间取出日期
                    $time_end   = $val['check_time'];
		    $time     = date("G");  //当前的整点
                     
                    if ((date('Y-m-d')>=$time_end) && ($time>=17)){
                        $return = '<span class="orderstate">已完结</span>';
                    }else {
                        $return = '<span class="orderstate" onclick="refund('.$val['out_trade_no'].','.$val['total_price'].','.$val['total_price'].');">点击申请退款</span>';
                    }
                     
                    if ($val['power']=='3'){
                        $return = '<span class="orderstate">已退款</span>';
                    }
                
                    $str .='<table width="98%" border="1" class="tlist" cellpadding="0" cellspacing="0">';
                    $str .='<tr>';
                    $str .='<td rowspan="4" width="35%" class="orderimg"><img src="'.__ROOT__.'/Public/Home/Images/danren.jpg" /></td>';
                    $str .='<td colspan="2"><h5 class="orderid">订单号:'.$val['out_trade_no'].'</h5>'.$return.'</td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2"><span class="ordertitle">'.$val['room_name'].'</span></td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2">'.$val['check_time'].'~'.$val['out_time'].'</td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2"><span class="totalprice">总价：￥'.$val['total_price'].'元</span></td>';
                    $str .='</tr>';
                    $str .='</table>';
                }
                
                break;
            case '2':
                $orders_room = $User->table('qdh_orders_conference')->where("openid='$openid' AND pay_state='1'")->order("time_end desc")->select();
                foreach ($orders_room as $key => $val){
                    $str .='<table width="98%" border="1" class="tlist" cellpadding="0" cellspacing="0">';
                    $str .='<tr>';
                    $str .='<td rowspan="4" width="35%" class="orderimg"><img src="'.__ROOT__.'/Public/Home/Images/danren.jpg" /></td>';
                    $str .='<td colspan="2"><h5 class="orderid">订单号:'.$val['out_trade_no'].'</h5><span class="orderstate">已完结</span></td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2"><span class="ordertitle">'.$val['conference_name'].'</span></td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2">'.$val['check_time'].'~'.$val['out_time'].'</td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2"><span class="totalprice">总价：￥'.$val['price'].'元</span></td>';
                    $str .='</tr>';
                    $str .='</table>';
                }
                
                break;
            case '3':
                $orders_room = $User->table('qdh_orders_recreation')->where("openid='$openid' AND pay_state='1'")->order("time_end desc")->select();
                foreach ($orders_room as $key => $val){
                    $str .='<table width="98%" border="1" class="tlist" cellpadding="0" cellspacing="0">';
                    $str .='<tr>';
                    $str .='<td rowspan="4" width="35%" class="orderimg"><img src="'.__ROOT__.'/Public/Home/Images/danren.jpg" /></td>';
                    $str .='<td colspan="2"><h5 class="orderid">订单号:'.$val['out_trade_no'].'</h5><span class="orderstate">已完结</span></td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2"><span class="ordertitle">'.$val['recreation_name'].'</span></td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2">'.$val['check_time'].'~'.$val['out_time'].'</td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2"><span class="totalprice">总价：￥'.$val['price'].'元</span></td>';
                    $str .='</tr>';
                    $str .='</table>';
                }
                break;
            case '4':
                $orders_room = $User->table('qdh_orders_restaurant')->where("openid='$openid' AND pay_state='1'")->order("time_end desc")->select();
                foreach ($orders_room as $key => $val){
                    $str .='<table width="98%" border="1" class="tlist" cellpadding="0" cellspacing="0">';
                    $str .='<tr>';
                    $str .='<td rowspan="4" width="35%" class="orderimg"><img src="'.__ROOT__.'/Public/Home/Images/danren.jpg" /></td>';
                    $str .='<td colspan="2"><h5 class="orderid">订单号:'.$val['out_trade_no'].'</h5><span class="orderstate">已完结</span></td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2"><span class="ordertitle">'.$val['restaurant_name'].'</span></td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2">'.$val['check_time'].'~'.$val['out_time'].'</td>';
                    $str .='</tr>';
                    $str .='<tr>';
                    $str .='<td colspan="2"><span class="totalprice">总价：￥'.$val['price'].'元</span></td>';
                    $str .='</tr>';
                    $str .='</table>';
                }
                break;
        }
        
        
        $this->assign('orders_room',$orders_room);
        $this->assign('openid',$openid);
	$this->assign('orders',$orders);
        $this->assign('str',$str);
        $this->display('historylists');
        
    }
  
    
    //退款方法操作
    public function refund_post(){
        $uri = "http://wx.veimx.com/Wx/example/refund.php";//这里换成自己的服务器的地址
        // 参数数组
    
        $out_trade_no = I('get.out_trade_no');
        $total_fee    = I('get.total_fee')*100;
        $refund_fee   = I('get.refund_fee')*100;
        $data = array (
            'out_trade_no' =>  $out_trade_no,
            'total_fee'    =>  $total_fee,
            'refund_fee'   =>  $refund_fee
        );
        $ch = curl_init ();
        curl_setopt ( $ch, CURLOPT_URL, $uri );
        curl_setopt ( $ch, CURLOPT_POST, 1 );
        curl_setopt ( $ch, CURLOPT_HEADER, 0 );
        curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
        curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
        $return = curl_exec ( $ch );
        curl_close ( $ch );
        $return =  json_decode($return,true);
        $this->refund_update($return,$out_trade_no);  //吧值传递个下一个处理 
    }
    
    
    ///////////////////////////私有方法建议不要动///////////////////////////////////////////////////
    
    private function refund_update($return,$out_trade_no){
        $User = new Model('Orders_room');
    
        if ($return['return_msg']=='OK' && $return['return_code'] == 'SUCCESS' && $return['result_code']== 'SUCCESS'){
            $sql = "UPDATE qdh_orders_room SET `power`= '3' WHERE out_trade_no=$out_trade_no ";
            $User->execute($sql);
            $this->success('退款申请成功,感谢您的支持',U('Index/get_user_info?orders=1'));
        }else {
            $this->error('退款申请失败!',U('Index/get_user_info?orders=1'));
        }
    
    }
    
    
}

