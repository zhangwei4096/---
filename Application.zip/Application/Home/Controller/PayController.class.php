<?php
namespace Home\Controller;
use Think\Controller;
use Think\Model;
//微信支付类
class PayController extends Controller {
 
    public function _initialize(){
        session_start();
    }
    
    public function weixinpay_js(){
        // 此处根据实际业务情况生成订单 然后拿着订单去支付
        
        $result = $_SESSION['user_info'];
        $id     = I('get.id',1,'intval'); ///页面传递过来的ID
        $state  = I('get.state',1,'intval'); //判断是什么房间
        
        $data['out_trade_no'] = time(); //商家订单号
        $data['check_time']   = $result['chcke_time'];   //入住时间    首页全局传递过来的数据
        $data['out_time']     = $result['out_time'];  //离店时间
        $data['people_number']= $result['man'];            //入住人数
        
        
        if ($state==1){
            //房间预订
            $User  = new Model("Orders_room");
            $result = $User->table('qdh_room')->where("id=$id")->find();
            $data['room_name']    = $result['room_name'];
            $data['price']        = $result['room_deposit']; //定金
	        $_SESSION['type']     = 1;  
            
        }else if ($state==2){
            //会议室预订 
            $User  = new Model("Orders_conference");
            $result = $User->table('qdh_conference')->where("id=$id")->find();
            $data['conference_name']    = $result['conference_name'];
            $data['price']              = $result['conference_deposit']; //定金
            $_SESSION['type']           = 2;  
        }elseif ($state==3){
            //娱乐室预订
            $User   = new Model("Orders_recreation");
            //用接收到的娱乐室信息ID来查询出基本的信息
            $result = $User->table("qdh_recreation_room")->where("id=$id")->find();
            $data['recreation_name'] = $result['recreation_name'];
            $data['price']           = $result['recreation_deposit'];//定金{娱乐室只有定金}
            $_SESSION['type']        = 3; 
             
        }elseif ($state==4){
            //餐饮预订
            $User = new Model("Orders_restaurant");
            $result = $User->table("qdh_restaurant")->where("id=$id")->find();
            $data['restaurant_name'] = $result['restaurant_name'];
            $data['price']           = $result['restaurant_price'];//价格
            $_SESSION['type']        = 4;
        }
        
        
        
           if ($User->add($data)){
               //现在这个订单号码是作为下一级支付页面的唯一ID了
              // 组合url
              
               $array = array('out_trade_no'=>$data['out_trade_no'],'type'=> $_SESSION['type'],'id'=>$id);
               
            if ($state==1){
                //房间预订
                $url=U('Api/Weixinpay/pay_room',$array);
            }elseif ($state==2){
                //会议室预订
                $url=U('Api/Weixinpay/pay_conference',$array);
            }elseif ($state==3){
                //娱乐室预订
                $url=U('Api/Weixinpay/pay_recreation',$array);
            }elseif ($state==4){
                //餐饮预订
                $url=U('Api/Weixinpay/pay_restaurant',$array);
            }
            
            // 前往支付
            redirect($url);
        }  
         
        
    }



}
?>
